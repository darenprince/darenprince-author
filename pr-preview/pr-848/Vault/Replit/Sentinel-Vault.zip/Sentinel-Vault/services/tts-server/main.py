import hashlib
import io
import logging
import os

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from pydantic import BaseModel

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Sentinel Vault TTS Service", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

_chatterbox_model = None
_engine = "loading"
_cache: dict[str, dict] = {}


def _load_chatterbox():
    global _chatterbox_model, _engine
    try:
        import torch
        from chatterbox.tts import ChatterboxTTS
        device = "cuda" if torch.cuda.is_available() else "cpu"
        logger.info(f"Loading Chatterbox TTS on {device}...")
        _chatterbox_model = ChatterboxTTS.from_pretrained(device=device)
        _engine = "chatterbox"
        logger.info("Chatterbox TTS loaded successfully")
    except Exception as exc:
        logger.error(f"Failed to load Chatterbox TTS: {exc}")
        _engine = "unavailable"


class SpeechRequest(BaseModel):
    model: str = "chatterbox"
    input: str
    voice: str = "default"
    speed: float = 1.0


@app.on_event("startup")
async def startup():
    import asyncio
    asyncio.create_task(asyncio.to_thread(_load_chatterbox))


@app.get("/health")
def health():
    return {
        "status": "ok",
        "engine": _engine,
        "model_loaded": _chatterbox_model is not None,
        "cached_phrases": len(_cache),
    }


@app.post("/v1/audio/speech")
async def generate_speech(req: SpeechRequest):
    text = req.input.strip()
    if not text:
        raise HTTPException(status_code=400, detail="Input text cannot be empty")
    text = text[:600]

    cache_key = hashlib.md5(text.encode("utf-8")).hexdigest()
    if cache_key in _cache:
        entry = _cache[cache_key]
        return Response(
            content=entry["data"],
            media_type=entry["mime"],
            headers={"X-Cache": "hit", "X-Engine": "chatterbox"},
        )

    if _engine == "loading":
        raise HTTPException(status_code=503, detail="Chatterbox TTS model is still loading. Please retry in a moment.")

    if _chatterbox_model is None:
        raise HTTPException(status_code=503, detail="Chatterbox TTS model is not available. The model failed to load.")

    try:
        import torch
        import numpy as np
        import wave
        import struct

        wav_tensor = _chatterbox_model.generate(text)
        sample_rate = _chatterbox_model.sr

        if isinstance(wav_tensor, torch.Tensor):
            audio_np = wav_tensor.squeeze().cpu().numpy()
        else:
            audio_np = np.array(wav_tensor).squeeze()

        if audio_np.dtype == np.float32 or audio_np.dtype == np.float64:
            audio_np = np.clip(audio_np, -1.0, 1.0)
            audio_int16 = (audio_np * 32767).astype(np.int16)
        else:
            audio_int16 = audio_np.astype(np.int16)

        buf = io.BytesIO()
        with wave.open(buf, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(audio_int16.tobytes())

        audio_bytes = buf.getvalue()
        _cache[cache_key] = {"data": audio_bytes, "mime": "audio/wav", "engine": "chatterbox"}
        return Response(
            content=audio_bytes,
            media_type="audio/wav",
            headers={"X-Cache": "miss", "X-Engine": "chatterbox"},
        )
    except Exception as exc:
        logger.error(f"Chatterbox generation error: {exc}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Chatterbox TTS generation failed: {exc}")
