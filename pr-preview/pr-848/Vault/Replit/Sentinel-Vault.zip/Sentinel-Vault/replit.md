# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Frontend**: React + Vite + Tailwind + shadcn/ui + wouter

## Structure

```text
artifacts-monorepo/
├── artifacts/              # Deployable applications
│   ├── api-server/         # Express API server
│   └── sentinel-vault/     # Sentinel Vault React frontend (previewPath: /)
├── services/               # Standalone backend microservices
│   └── tts-server/         # Python FastAPI TTS service (port 5000)
├── lib/                    # Shared libraries
│   ├── api-spec/           # OpenAPI spec + Orval codegen config
│   ├── api-client-react/   # Generated React Query hooks
│   ├── api-zod/            # Generated Zod schemas from OpenAPI
│   └── db/                 # Drizzle ORM schema + DB connection
├── scripts/                # Utility scripts (single workspace package)
│   └── src/                # Individual .ts scripts
├── pnpm-workspace.yaml     # pnpm workspace (artifacts/*, lib/*, lib/integrations/*, scripts)
├── tsconfig.base.json      # Shared TS options (composite, bundler resolution, es2022)
├── tsconfig.json           # Root TS project references
└── package.json            # Root package with hoisted devDeps
```

## Sentinel Vault

**Sentinel Vault** is a personal safety and evidence continuity platform. Features:

- **Evidence Vaults**: Secure compartmentalized storage for documents, audio, video, IDs, legal records
- **Incident Records**: Structured incident logging with severity, status, and timeline
- **Timed Check-ins**: Arm safety intervals — missed check-ins trigger escalation
- **Trusted Circle**: Role-based contacts (family, attorney, advocate, journalist, etc.)
- **SOS Center**: Distress signal trigger with configurable contact routing
- **Deadman Rules**: Automated evidence release if user goes silent
- **Dashboard**: Command center with security status overview and activity log

### Design System

- **Fonts**: Inter (sans-serif) + JetBrains Mono (monospace)
- **Brand colors**: Orange primary `hsl(25 90% 50%)`, dark navy background `hsl(222 47% 6%)`, sidebar `hsl(222 47% 4%)`
- **Logo**: Shield with orange eye — `@assets/F1B418FA-4D83-4684-9599-1CF1D20306A4_1774910006252.png`
- **Theme**: Dark-only, glassmorphism panels, grid pattern backgrounds, glow utilities
- **CSS**: Tailwind CSS v4 with custom theme in `index.css`

### TTS (Text-to-Speech)

- **Engine**: Chatterbox-only (no gTTS, no Web Speech fallback)
- **Scope**: Slideshow tour narration only (`/tour` page). Removed from SOS and check-ins.
- **Server**: Python FastAPI on port 5000, proxied via Express at `/api/tts/*`
- **Client**: `useTTS` hook with 10-second retry backoff for availability checks, audio caching, mute toggle

### DB Schema

Tables: `vaults`, `evidence_files`, `incidents`, `checkins`, `trusted_contacts`, `sos_alerts`, `deadman_rules`, `audit_logs`

### API Routes

All routes under `/api/`:
- `GET/POST /vaults`, `GET/PUT/DELETE /vaults/:id`
- `GET/POST /vaults/:vaultId/files`, `DELETE /files/:id`
- `GET/POST /incidents`, `GET/PUT/DELETE /incidents/:id`
- `GET/POST /checkins`, `GET/DELETE /checkins/:id`, `POST /checkins/:id/confirm`
- `GET/POST /contacts`, `PUT/DELETE /contacts/:id`
- `GET/POST /sos`, `POST /sos/:id/resolve`
- `GET/POST /deadman`, `PUT/DELETE /deadman/:id`, `POST /deadman/:id/renew`
- `GET /dashboard/summary`
- `GET /audit-log` (supports `?category=`, `?limit=`, `?offset=`)

## TypeScript & Composite Projects

Every package extends `tsconfig.base.json` which sets `composite: true`. The root `tsconfig.json` lists all packages as project references. This means:

- **Always typecheck from the root** — run `pnpm run typecheck` (which runs `tsc --build --emitDeclarationOnly`). This builds the full dependency graph so that cross-package imports resolve correctly. Running `tsc` inside a single package will fail if its dependencies haven't been built yet.
- **`emitDeclarationOnly`** — we only emit `.d.ts` files during typecheck; actual JS bundling is handled by esbuild/tsx/vite...etc, not `tsc`.
- **Project references** — when package A depends on package B, A's `tsconfig.json` must list B in its `references` array. `tsc --build` uses this to determine build order and skip up-to-date packages.

## Root Scripts

- `pnpm run build` — runs `typecheck` first, then recursively runs `build` in all packages that define it
- `pnpm run typecheck` — runs `tsc --build --emitDeclarationOnly` using project references

## Packages

### `artifacts/api-server` (`@workspace/api-server`)

Express 5 API server. Routes live in `src/routes/` and use `@workspace/api-zod` for request and response validation and `@workspace/db` for persistence.

### `artifacts/sentinel-vault` (`@workspace/sentinel-vault`)

React + Vite frontend for Sentinel Vault. Uses generated React Query hooks from `@workspace/api-client-react`.

### `lib/db` (`@workspace/db`)

Database layer using Drizzle ORM with PostgreSQL. Exports a Drizzle client instance and schema models.

Production migrations are handled by Replit when publishing. In development, we just use `pnpm --filter @workspace/db run push`, and we fallback to `pnpm --filter @workspace/db run push-force`.

### `lib/api-spec` (`@workspace/api-spec`)

Owns the OpenAPI 3.1 spec (`openapi.yaml`) and the Orval config (`orval.config.ts`). Running codegen produces output into two sibling packages:

1. `lib/api-client-react/src/generated/` — React Query hooks + fetch client
2. `lib/api-zod/src/generated/` — Zod schemas

Run codegen: `pnpm --filter @workspace/api-spec run codegen`
