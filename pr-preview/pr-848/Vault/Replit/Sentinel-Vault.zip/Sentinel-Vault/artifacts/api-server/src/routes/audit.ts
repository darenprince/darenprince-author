import { Router, type IRouter } from "express";
import { desc, sql, eq, ilike } from "drizzle-orm";
import { db, auditLogsTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/audit-log", async (req, res): Promise<void> => {
  const limit = Math.min(parseInt(req.query.limit as string) || 50, 200);
  const offset = parseInt(req.query.offset as string) || 0;
  const category = req.query.category as string | undefined;

  const hasFilter = category && category !== "all";

  const logsQuery = hasFilter
    ? db.select().from(auditLogsTable).where(eq(auditLogsTable.category, category)).orderBy(desc(auditLogsTable.createdAt)).limit(limit).offset(offset)
    : db.select().from(auditLogsTable).orderBy(desc(auditLogsTable.createdAt)).limit(limit).offset(offset);

  const countQuery = hasFilter
    ? db.select({ count: sql<number>`count(*)::int` }).from(auditLogsTable).where(eq(auditLogsTable.category, category))
    : db.select({ count: sql<number>`count(*)::int` }).from(auditLogsTable);

  const [logs, [{ count }]] = await Promise.all([logsQuery, countQuery]);

  res.json({ logs, total: count });
});

export default router;
