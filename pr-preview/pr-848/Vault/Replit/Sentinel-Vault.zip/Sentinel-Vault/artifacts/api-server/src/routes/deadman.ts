import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, deadmanRulesTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/deadman", async (_req, res): Promise<void> => {
  const rules = await db.select().from(deadmanRulesTable).orderBy(deadmanRulesTable.createdAt);
  res.json(rules);
});

router.post("/deadman", async (req, res): Promise<void> => {
  const { name, description, triggerAfterHours, releaseTarget, gracePeriodMinutes, vaultIds, contactIds } = req.body;
  if (!name || !triggerAfterHours) { res.status(400).json({ error: "name and triggerAfterHours are required" }); return; }
  const now = new Date();
  const willTriggerAt = new Date(now.getTime() + triggerAfterHours * 60 * 60 * 1000);
  const [rule] = await db
    .insert(deadmanRulesTable)
    .values({
      name,
      description,
      triggerAfterHours,
      status: "active",
      releaseTarget: releaseTarget ?? "trusted_circle",
      gracePeriodMinutes: gracePeriodMinutes ?? 60,
      vaultIds: vaultIds ?? [],
      contactIds: contactIds ?? [],
      lastRenewedAt: now,
      willTriggerAt,
    })
    .returning();
  res.status(201).json(rule);
});

router.put("/deadman/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const { name, description, triggerAfterHours, status, releaseTarget, gracePeriodMinutes, vaultIds, contactIds } = req.body;
  const [rule] = await db
    .update(deadmanRulesTable)
    .set({
      ...(name !== undefined && { name }),
      ...(description !== undefined && { description }),
      ...(triggerAfterHours !== undefined && { triggerAfterHours }),
      ...(status !== undefined && { status }),
      ...(releaseTarget !== undefined && { releaseTarget }),
      ...(gracePeriodMinutes !== undefined && { gracePeriodMinutes }),
      ...(vaultIds !== undefined && { vaultIds }),
      ...(contactIds !== undefined && { contactIds }),
    })
    .where(eq(deadmanRulesTable.id, id))
    .returning();
  if (!rule) { res.status(404).json({ error: "Rule not found" }); return; }
  res.json(rule);
});

router.delete("/deadman/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(deadmanRulesTable).where(eq(deadmanRulesTable.id, id));
  res.sendStatus(204);
});

router.post("/deadman/:id/renew", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [existing] = await db.select().from(deadmanRulesTable).where(eq(deadmanRulesTable.id, id));
  if (!existing) { res.status(404).json({ error: "Rule not found" }); return; }
  const now = new Date();
  const willTriggerAt = new Date(now.getTime() + existing.triggerAfterHours * 60 * 60 * 1000);
  const [rule] = await db
    .update(deadmanRulesTable)
    .set({ lastRenewedAt: now, willTriggerAt, status: "active" })
    .where(eq(deadmanRulesTable.id, id))
    .returning();
  res.json(rule);
});

export default router;
