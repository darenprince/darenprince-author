import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db, vaultsTable, evidenceFilesTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/vaults", async (req, res): Promise<void> => {
  const vaults = await db.select().from(vaultsTable).orderBy(vaultsTable.createdAt);
  const fileCounts = await db
    .select({ vaultId: evidenceFilesTable.vaultId, count: sql<number>`count(*)::int` })
    .from(evidenceFilesTable)
    .groupBy(evidenceFilesTable.vaultId);
  const countMap = new Map(fileCounts.map((r) => [r.vaultId, r.count]));
  res.json(vaults.map((v) => ({ ...v, fileCount: countMap.get(v.id) ?? 0 })));
});

router.post("/vaults", async (req, res): Promise<void> => {
  const { name, description, category, isLocked } = req.body;
  if (!name) {
    res.status(400).json({ error: "name is required" });
    return;
  }
  const [vault] = await db
    .insert(vaultsTable)
    .values({ name, description, category: category ?? "other", isLocked: isLocked ?? false })
    .returning();
  res.status(201).json({ ...vault, fileCount: 0 });
});

router.get("/vaults/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [vault] = await db.select().from(vaultsTable).where(eq(vaultsTable.id, id));
  if (!vault) { res.status(404).json({ error: "Vault not found" }); return; }
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(evidenceFilesTable)
    .where(eq(evidenceFilesTable.vaultId, id));
  res.json({ ...vault, fileCount: count ?? 0 });
});

router.put("/vaults/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const { name, description, category, status, isLocked } = req.body;
  const [vault] = await db
    .update(vaultsTable)
    .set({ ...(name !== undefined && { name }), ...(description !== undefined && { description }), ...(category !== undefined && { category }), ...(status !== undefined && { status }), ...(isLocked !== undefined && { isLocked }) })
    .where(eq(vaultsTable.id, id))
    .returning();
  if (!vault) { res.status(404).json({ error: "Vault not found" }); return; }
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(evidenceFilesTable)
    .where(eq(evidenceFilesTable.vaultId, id));
  res.json({ ...vault, fileCount: count ?? 0 });
});

router.delete("/vaults/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(vaultsTable).where(eq(vaultsTable.id, id));
  res.sendStatus(204);
});

router.get("/vaults/:vaultId/files", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.vaultId) ? req.params.vaultId[0] : req.params.vaultId;
  const vaultId = parseInt(raw, 10);
  if (isNaN(vaultId)) { res.status(400).json({ error: "Invalid vaultId" }); return; }
  const files = await db.select().from(evidenceFilesTable).where(eq(evidenceFilesTable.vaultId, vaultId)).orderBy(evidenceFilesTable.createdAt);
  res.json(files);
});

router.post("/vaults/:vaultId/files", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.vaultId) ? req.params.vaultId[0] : req.params.vaultId;
  const vaultId = parseInt(raw, 10);
  if (isNaN(vaultId)) { res.status(400).json({ error: "Invalid vaultId" }); return; }
  const { name, fileType, mimeType, sizeBytes, notes, tags, capturedAt } = req.body;
  if (!name) { res.status(400).json({ error: "name is required" }); return; }
  const [file] = await db
    .insert(evidenceFilesTable)
    .values({ vaultId, name, fileType: fileType ?? "other", mimeType, sizeBytes, notes, tags, capturedAt: capturedAt ? new Date(capturedAt) : null })
    .returning();
  res.status(201).json(file);
});

router.delete("/files/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(evidenceFilesTable).where(eq(evidenceFilesTable.id, id));
  res.sendStatus(204);
});

export default router;
