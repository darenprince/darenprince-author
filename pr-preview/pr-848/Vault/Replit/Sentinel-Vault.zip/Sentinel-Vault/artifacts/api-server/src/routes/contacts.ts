import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, trustedContactsTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/contacts", async (_req, res): Promise<void> => {
  const contacts = await db.select().from(trustedContactsTable).orderBy(trustedContactsTable.createdAt);
  res.json(contacts);
});

router.post("/contacts", async (req, res): Promise<void> => {
  const { name, email, phone, relationship, role, receivesSos, receivesCheckinFailure, receivesDeadmanRelease, notes } = req.body;
  if (!name) { res.status(400).json({ error: "name is required" }); return; }
  const [contact] = await db
    .insert(trustedContactsTable)
    .values({
      name,
      email,
      phone,
      relationship,
      role: role ?? "other",
      receivesSos: receivesSos ?? false,
      receivesCheckinFailure: receivesCheckinFailure ?? false,
      receivesDeadmanRelease: receivesDeadmanRelease ?? false,
      notes,
    })
    .returning();
  res.status(201).json(contact);
});

router.put("/contacts/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const { name, email, phone, relationship, role, receivesSos, receivesCheckinFailure, receivesDeadmanRelease, notes } = req.body;
  const [contact] = await db
    .update(trustedContactsTable)
    .set({
      ...(name !== undefined && { name }),
      ...(email !== undefined && { email }),
      ...(phone !== undefined && { phone }),
      ...(relationship !== undefined && { relationship }),
      ...(role !== undefined && { role }),
      ...(receivesSos !== undefined && { receivesSos }),
      ...(receivesCheckinFailure !== undefined && { receivesCheckinFailure }),
      ...(receivesDeadmanRelease !== undefined && { receivesDeadmanRelease }),
      ...(notes !== undefined && { notes }),
    })
    .where(eq(trustedContactsTable.id, id))
    .returning();
  if (!contact) { res.status(404).json({ error: "Contact not found" }); return; }
  res.json(contact);
});

router.delete("/contacts/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(trustedContactsTable).where(eq(trustedContactsTable.id, id));
  res.sendStatus(204);
});

export default router;
