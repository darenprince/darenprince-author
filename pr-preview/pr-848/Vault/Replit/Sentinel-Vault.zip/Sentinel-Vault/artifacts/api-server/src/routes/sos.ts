import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, sosAlertsTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/sos", async (_req, res): Promise<void> => {
  const alerts = await db.select().from(sosAlertsTable).orderBy(sosAlertsTable.triggeredAt);
  res.json(alerts);
});

router.post("/sos", async (req, res): Promise<void> => {
  const { message, location, includesLocation, notifiedContactIds } = req.body;
  const [alert] = await db
    .insert(sosAlertsTable)
    .values({
      status: "active",
      message,
      location,
      includesLocation: includesLocation ?? false,
      notifiedContactIds: notifiedContactIds ?? [],
    })
    .returning();
  res.status(201).json(alert);
});

router.post("/sos/:id/resolve", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [alert] = await db
    .update(sosAlertsTable)
    .set({ status: "resolved", resolvedAt: new Date() })
    .where(eq(sosAlertsTable.id, id))
    .returning();
  if (!alert) { res.status(404).json({ error: "SOS alert not found" }); return; }
  res.json(alert);
});

export default router;
