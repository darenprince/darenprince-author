import { Router, type IRouter } from "express";
import healthRouter from "./health";
import vaultsRouter from "./vaults";
import incidentsRouter from "./incidents";
import checkinsRouter from "./checkins";
import contactsRouter from "./contacts";
import sosRouter from "./sos";
import deadmanRouter from "./deadman";
import dashboardRouter from "./dashboard";
import ttsRouter from "./tts";
import auditRouter from "./audit";

const router: IRouter = Router();

router.use(healthRouter);
router.use(dashboardRouter);
router.use(vaultsRouter);
router.use(incidentsRouter);
router.use(checkinsRouter);
router.use(contactsRouter);
router.use(sosRouter);
router.use(deadmanRouter);
router.use(ttsRouter);
router.use(auditRouter);

export default router;
