import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db, vaultsTable, evidenceFilesTable, incidentsTable, checkinsTable, trustedContactsTable, sosAlertsTable, deadmanRulesTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/dashboard/summary", async (_req, res): Promise<void> => {
  const [[vaultCount], [fileCount], [incidentCount], [checkinCount], [sosCount], [deadmanCount], [contactCount]] = await Promise.all([
    db.select({ count: sql<number>`count(*)::int` }).from(vaultsTable),
    db.select({ count: sql<number>`count(*)::int` }).from(evidenceFilesTable),
    db.select({ count: sql<number>`count(*)::int` }).from(incidentsTable),
    db.select({ count: sql<number>`count(*)::int` }).from(checkinsTable).where(eq(checkinsTable.status, "armed")),
    db.select({ count: sql<number>`count(*)::int` }).from(sosAlertsTable).where(eq(sosAlertsTable.status, "active")),
    db.select({ count: sql<number>`count(*)::int` }).from(deadmanRulesTable).where(eq(deadmanRulesTable.status, "active")),
    db.select({ count: sql<number>`count(*)::int` }).from(trustedContactsTable),
  ]);

  const recentVaults = await db.select().from(vaultsTable).orderBy(sql`created_at desc`).limit(3);
  const recentIncidents = await db.select().from(incidentsTable).orderBy(sql`created_at desc`).limit(3);
  const recentFiles = await db.select().from(evidenceFilesTable).orderBy(sql`created_at desc`).limit(2);
  const recentSos = await db.select().from(sosAlertsTable).orderBy(sql`triggered_at desc`).limit(2);

  const activity = [
    ...recentVaults.map((v) => ({ id: `vault-${v.id}`, type: "vault_created" as const, description: `Vault created: ${v.name}`, createdAt: v.createdAt.toISOString() })),
    ...recentIncidents.map((i) => ({ id: `incident-${i.id}`, type: "incident_created" as const, description: `Incident logged: ${i.title}`, createdAt: i.createdAt.toISOString() })),
    ...recentFiles.map((f) => ({ id: `file-${f.id}`, type: "file_added" as const, description: `File added: ${f.name}`, createdAt: f.createdAt.toISOString() })),
    ...recentSos.map((s) => ({ id: `sos-${s.id}`, type: "sos_triggered" as const, description: `SOS triggered`, createdAt: s.triggeredAt.toISOString() })),
  ].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 8);

  res.json({
    totalVaults: vaultCount.count,
    totalFiles: fileCount.count,
    totalIncidents: incidentCount.count,
    activeCheckins: checkinCount.count,
    activeSosAlerts: sosCount.count,
    activeDeadmanRules: deadmanCount.count,
    totalContacts: contactCount.count,
    recentActivity: activity,
  });
});

export default router;
