import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, checkinsTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/checkins", async (_req, res): Promise<void> => {
  const checkins = await db.select().from(checkinsTable).orderBy(checkinsTable.createdAt);
  res.json(checkins);
});

router.post("/checkins", async (req, res): Promise<void> => {
  const { label, intervalMinutes, notes } = req.body;
  if (!label || !intervalMinutes) { res.status(400).json({ error: "label and intervalMinutes are required" }); return; }
  const nextDueAt = new Date(Date.now() + intervalMinutes * 60 * 1000);
  const [checkin] = await db
    .insert(checkinsTable)
    .values({ label, intervalMinutes, status: "armed", nextDueAt, missedCount: 0, notes })
    .returning();
  res.status(201).json(checkin);
});

router.get("/checkins/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [checkin] = await db.select().from(checkinsTable).where(eq(checkinsTable.id, id));
  if (!checkin) { res.status(404).json({ error: "Check-in not found" }); return; }
  res.json(checkin);
});

router.delete("/checkins/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.update(checkinsTable).set({ status: "disarmed" }).where(eq(checkinsTable.id, id));
  res.sendStatus(204);
});

router.post("/checkins/:id/confirm", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [existing] = await db.select().from(checkinsTable).where(eq(checkinsTable.id, id));
  if (!existing) { res.status(404).json({ error: "Check-in not found" }); return; }
  const now = new Date();
  const nextDueAt = new Date(now.getTime() + existing.intervalMinutes * 60 * 1000);
  const [checkin] = await db
    .update(checkinsTable)
    .set({ status: "confirmed", lastConfirmedAt: now, nextDueAt })
    .where(eq(checkinsTable.id, id))
    .returning();
  res.json(checkin);
});

export default router;
