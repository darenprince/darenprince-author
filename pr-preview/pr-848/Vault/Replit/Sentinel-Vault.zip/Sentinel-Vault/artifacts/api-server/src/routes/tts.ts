import { Router } from "express";

const TTS_BASE = "http://localhost:5000";

const router = Router();

router.get("/tts/health", async (_req, res) => {
  try {
    const response = await fetch(`${TTS_BASE}/health`, { signal: AbortSignal.timeout(3000) });
    const data = await response.json();
    res.json(data);
  } catch {
    res.status(503).json({ status: "unavailable", message: "TTS service not running" });
  }
});

router.post("/tts/v1/audio/speech", async (req, res) => {
  try {
    const response = await fetch(`${TTS_BASE}/v1/audio/speech`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(req.body),
      signal: AbortSignal.timeout(45000),
    });

    if (!response.ok) {
      const errText = await response.text();
      res.status(response.status).json({ error: errText });
      return;
    }

    const contentType = response.headers.get("content-type") ?? "audio/wav";
    const xEngine = response.headers.get("x-engine") ?? "unknown";
    const xCache = response.headers.get("x-cache") ?? "miss";
    const buffer = await response.arrayBuffer();

    res.set("Content-Type", contentType);
    res.set("Cache-Control", "public, max-age=86400");
    res.set("X-Engine", xEngine);
    res.set("X-Cache", xCache);
    res.send(Buffer.from(buffer));
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    res.status(503).json({ error: "TTS service unavailable", detail: msg });
  }
});

export default router;
