import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, incidentsTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/incidents", async (_req, res): Promise<void> => {
  const incidents = await db.select().from(incidentsTable).orderBy(incidentsTable.createdAt);
  res.json(incidents);
});

router.post("/incidents", async (req, res): Promise<void> => {
  const { title, description, severity, location, involvedParties, vaultId, occurredAt } = req.body;
  if (!title) { res.status(400).json({ error: "title is required" }); return; }
  const [incident] = await db
    .insert(incidentsTable)
    .values({
      title,
      description,
      severity: severity ?? "medium",
      location,
      involvedParties,
      vaultId: vaultId ?? null,
      occurredAt: occurredAt ? new Date(occurredAt) : null,
    })
    .returning();
  res.status(201).json(incident);
});

router.get("/incidents/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [incident] = await db.select().from(incidentsTable).where(eq(incidentsTable.id, id));
  if (!incident) { res.status(404).json({ error: "Incident not found" }); return; }
  res.json(incident);
});

router.put("/incidents/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const { title, description, severity, status, location, involvedParties, vaultId, occurredAt } = req.body;
  const [incident] = await db
    .update(incidentsTable)
    .set({
      ...(title !== undefined && { title }),
      ...(description !== undefined && { description }),
      ...(severity !== undefined && { severity }),
      ...(status !== undefined && { status }),
      ...(location !== undefined && { location }),
      ...(involvedParties !== undefined && { involvedParties }),
      ...(vaultId !== undefined && { vaultId }),
      ...(occurredAt !== undefined && { occurredAt: occurredAt ? new Date(occurredAt) : null }),
    })
    .where(eq(incidentsTable.id, id))
    .returning();
  if (!incident) { res.status(404).json({ error: "Incident not found" }); return; }
  res.json(incident);
});

router.delete("/incidents/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(incidentsTable).where(eq(incidentsTable.id, id));
  res.sendStatus(204);
});

export default router;
