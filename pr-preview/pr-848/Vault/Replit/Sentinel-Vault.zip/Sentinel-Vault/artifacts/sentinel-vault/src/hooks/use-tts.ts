import { useRef, useCallback, useState, useEffect } from "react";

const audioCache = new Map<string, string>();
let ttsAvailable: boolean | null = null;
let lastCheckTime = 0;

async function checkTtsAvailability(): Promise<boolean> {
  const now = Date.now();
  if (ttsAvailable === true) return true;
  if (ttsAvailable === false && now - lastCheckTime < 10000) return false;

  lastCheckTime = now;
  try {
    const res = await fetch("/api/tts/health", { signal: AbortSignal.timeout(3000) });
    if (!res.ok) { ttsAvailable = false; return false; }
    const data = await res.json();
    ttsAvailable = data.engine === "chatterbox";
  } catch {
    ttsAvailable = false;
  }
  return ttsAvailable;
}

export function useTTS() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [engine, setEngine] = useState<"chatterbox" | "idle">("idle");

  useEffect(() => {
    checkTtsAvailability();
  }, []);

  const stop = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      audioRef.current = null;
    }
    setIsPlaying(false);
    setIsLoading(false);
    setEngine("idle");
  }, []);

  const _playBlob = useCallback(
    (url: string) => {
      const audio = new Audio(url);
      audioRef.current = audio;
      audio.onended = () => {
        setIsPlaying(false);
        setEngine("idle");
      };
      audio.onerror = () => {
        setIsPlaying(false);
        setEngine("idle");
      };
      setIsPlaying(true);
      setEngine("chatterbox");
      audio.play().catch(() => {
        setIsPlaying(false);
        setEngine("idle");
      });
    },
    []
  );

  const speak = useCallback(
    async (text: string) => {
      if (isMuted) return;
      stop();

      const cached = audioCache.get(text);
      if (cached) {
        _playBlob(cached);
        return;
      }

      const available = await checkTtsAvailability();
      if (!available) return;

      setIsLoading(true);
      try {
        const res = await fetch("/api/tts/v1/audio/speech", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ model: "chatterbox", input: text, voice: "default" }),
          signal: AbortSignal.timeout(60000),
        });

        if (!res.ok) throw new Error(`TTS HTTP ${res.status}`);

        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        audioCache.set(text, url);

        if (!isMuted) {
          setIsLoading(false);
          _playBlob(url);
        } else {
          setIsLoading(false);
        }
      } catch {
        setIsLoading(false);
        ttsAvailable = false;
      }
    },
    [isMuted, stop, _playBlob]
  );

  const preload = useCallback(async (text: string) => {
    if (audioCache.has(text)) return;
    const available = await checkTtsAvailability();
    if (!available) return;
    try {
      const res = await fetch("/api/tts/v1/audio/speech", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: "chatterbox", input: text, voice: "default" }),
        signal: AbortSignal.timeout(60000),
      });
      if (!res.ok) return;
      const blob = await res.blob();
      audioCache.set(text, URL.createObjectURL(blob));
    } catch {
    }
  }, []);

  const toggleMute = useCallback(() => {
    setIsMuted((prev) => {
      if (!prev) stop();
      return !prev;
    });
  }, [stop]);

  return { speak, stop, preload, toggleMute, isLoading, isPlaying, isMuted, engine };
}
