import { useGetDashboardSummary, getGetDashboardSummaryQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Database, AlertTriangle, Timer, Radio, Skull, Activity, ShieldAlert, ShieldCheck, ArrowRight, ScrollText } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { formatTimeAgo } from "@/lib/format";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { data: summary, isLoading } = useGetDashboardSummary({
    query: {
      queryKey: getGetDashboardSummaryQueryKey()
    }
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex flex-col gap-2">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-5 w-72" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1,2,3,4].map(i => <Skeleton key={i} className="h-28 w-full rounded-xl" />)}
        </div>
        <Skeleton className="h-80 w-full rounded-xl" />
      </div>
    );
  }

  if (!summary) return null;

  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight mb-1">{greeting}</h1>
          <p className="text-muted-foreground text-sm">System overview and recent activity</p>
        </div>

        <div className={`flex items-center gap-2.5 px-4 py-2 border rounded-lg text-sm font-medium ${
          summary.activeSosAlerts > 0
            ? "border-destructive/50 bg-destructive/8 text-destructive"
            : "border-primary/30 bg-primary/8 text-primary"
        }`}>
          {summary.activeSosAlerts > 0 ? (
            <>
              <ShieldAlert className="h-4 w-4 animate-pulse" />
              <span className="font-mono text-xs tracking-wider">CRITICAL</span>
            </>
          ) : (
            <>
              <ShieldCheck className="h-4 w-4" />
              <span className="font-mono text-xs tracking-wider">SECURE</span>
            </>
          )}
        </div>
      </div>

      {summary.activeSosAlerts > 0 && (
        <div className="bg-destructive/10 border border-destructive/30 p-5 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <Radio className="h-6 w-6 text-destructive animate-pulse mt-0.5" />
            <div>
              <h3 className="text-base font-semibold text-destructive">Active Distress Signal</h3>
              <p className="text-destructive/70 mt-0.5 text-sm">Emergency broadcast transmitting to trusted circle.</p>
            </div>
          </div>
          <Link href="/sos">
            <Button variant="destructive" size="sm" className="font-medium tracking-wide">Manage Alert</Button>
          </Link>
        </div>
      )}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatusCard 
          title="Evidence Vaults" 
          value={summary.totalVaults.toString()} 
          icon={Database} 
          href="/vaults"
          sub={`${summary.totalFiles} files`}
        />
        <StatusCard 
          title="Active Check-ins" 
          value={summary.activeCheckins.toString()} 
          icon={Timer} 
          href="/checkins"
          sub={summary.activeCheckins > 0 ? "Timers running" : "No active timers"}
          accent={summary.activeCheckins > 0}
        />
        <StatusCard 
          title="Open Incidents" 
          value={summary.totalIncidents.toString()} 
          icon={AlertTriangle} 
          href="/incidents"
          sub="Recorded events"
          accent={summary.totalIncidents > 0}
        />
        <StatusCard 
          title="Deadman Rules" 
          value={summary.activeDeadmanRules.toString()} 
          icon={Skull} 
          href="/deadman"
          sub="Active triggers"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 border-border/50 shadow-none bg-card/50">
          <CardHeader className="pb-3 px-5 pt-5">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Activity className="h-4 w-4" />
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent className="px-5 pb-5">
            {summary.recentActivity.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground text-sm bg-background/50 rounded-lg border border-dashed border-border/50">
                No recent activity recorded.
              </div>
            ) : (
              <div className="space-y-4">
                {summary.recentActivity.map((activity) => (
                  <div key={activity.id} className="flex gap-3 relative">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary/60 mt-2 z-10 shrink-0" />
                    <div className="absolute left-[2px] top-4 bottom-[-16px] w-px bg-border/40 last:hidden" />
                    <div className="min-w-0">
                      <p className="text-sm leading-snug">{activity.description}</p>
                      <p className="text-xs text-muted-foreground mt-0.5 font-mono">
                        {formatTimeAgo(activity.createdAt)}
                      </p>
                    </div>
                  </div>
                ))}

                <Link href="/audit-log">
                  <Button variant="ghost" size="sm" className="w-full mt-2 text-muted-foreground hover:text-foreground text-xs gap-1.5">
                    <ScrollText className="h-3.5 w-3.5" />
                    View Full Audit Log
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="space-y-3">
          <p className="text-sm font-medium text-muted-foreground px-1">Quick Actions</p>
          
          <Link href="/incidents/new">
            <Card className="hover:border-primary/40 hover:bg-primary/3 transition-all cursor-pointer border-border/50 group overflow-hidden relative">
              <CardContent className="p-4 flex items-center gap-3">
                <div className="p-2.5 bg-secondary/80 rounded-lg group-hover:bg-primary/15 group-hover:text-primary transition-colors">
                  <AlertTriangle className="h-5 w-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-sm">Log Incident</h4>
                  <p className="text-xs text-muted-foreground mt-0.5">Record a new event</p>
                </div>
                <ArrowRight className="h-4 w-4 text-muted-foreground/40 group-hover:text-primary transition-colors" />
              </CardContent>
            </Card>
          </Link>

          <Link href="/checkins">
            <Card className="hover:border-accent/40 hover:bg-accent/3 transition-all cursor-pointer border-border/50 group overflow-hidden relative">
              <CardContent className="p-4 flex items-center gap-3">
                <div className="p-2.5 bg-secondary/80 rounded-lg group-hover:bg-accent/15 group-hover:text-accent transition-colors">
                  <Timer className="h-5 w-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-sm">Arm Check-in</h4>
                  <p className="text-xs text-muted-foreground mt-0.5">Start a safety countdown</p>
                </div>
                <ArrowRight className="h-4 w-4 text-muted-foreground/40 group-hover:text-accent transition-colors" />
              </CardContent>
            </Card>
          </Link>

          <Link href="/vaults">
            <Card className="hover:border-primary/40 hover:bg-primary/3 transition-all cursor-pointer border-border/50 group overflow-hidden relative">
              <CardContent className="p-4 flex items-center gap-3">
                <div className="p-2.5 bg-secondary/80 rounded-lg group-hover:bg-primary/15 group-hover:text-primary transition-colors">
                  <Database className="h-5 w-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-sm">Store Evidence</h4>
                  <p className="text-xs text-muted-foreground mt-0.5">Upload files to a vault</p>
                </div>
                <ArrowRight className="h-4 w-4 text-muted-foreground/40 group-hover:text-primary transition-colors" />
              </CardContent>
            </Card>
          </Link>
        </div>
      </div>
    </div>
  );
}

function StatusCard({ 
  title, 
  value, 
  icon: Icon, 
  href, 
  sub,
  accent
}: { 
  title: string; 
  value: string; 
  icon: any; 
  href: string;
  sub?: string;
  accent?: boolean;
}) {
  return (
    <Link href={href}>
      <Card className="hover:border-primary/30 transition-all cursor-pointer h-full border-border/50 bg-card/60 hover:bg-card group">
        <CardContent className="p-4">
          <div className="flex justify-between items-start mb-3">
            <p className="text-xs text-muted-foreground font-medium">{title}</p>
            <div className={`p-1.5 rounded-md bg-secondary/60 ${accent ? "text-primary" : "text-muted-foreground"} group-hover:bg-primary/10 group-hover:text-primary transition-colors`}>
              <Icon className="h-4 w-4" />
            </div>
          </div>
          <h3 className={`text-3xl font-semibold tracking-tight font-mono ${accent ? "text-primary" : ""}`}>{value}</h3>
          {sub && (
            <p className="text-xs text-muted-foreground mt-1">{sub}</p>
          )}
        </CardContent>
      </Card>
    </Link>
  );
}
