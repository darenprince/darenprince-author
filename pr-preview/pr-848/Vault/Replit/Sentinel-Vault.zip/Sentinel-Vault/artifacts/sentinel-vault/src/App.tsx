import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout";
import NotFound from "@/pages/not-found";

import LandingPage from "@/pages/landing";
import TourPage from "@/pages/tour";
import Dashboard from "@/pages/dashboard";
import SosCenter from "@/pages/sos/index";
import Checkins from "@/pages/checkins/index";
import Vaults from "@/pages/vaults/index";
import VaultDetail from "@/pages/vaults/detail";
import Incidents from "@/pages/incidents/index";
import IncidentDetail from "@/pages/incidents/detail";
import NewIncident from "@/pages/incidents/new";
import Contacts from "@/pages/contacts/index";
import DeadmanRules from "@/pages/deadman/index";
import Settings from "@/pages/settings";
import AuditLog from "@/pages/audit-log";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

function AppContent() {
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/tour" component={TourPage} />
      <Route path="/:rest*">
        <Layout>
          <Switch>
            <Route path="/dashboard" component={Dashboard} />
            <Route path="/sos" component={SosCenter} />
            <Route path="/checkins" component={Checkins} />
            <Route path="/vaults" component={Vaults} />
            <Route path="/vaults/:id" component={VaultDetail} />
            <Route path="/incidents/new" component={NewIncident} />
            <Route path="/incidents/:id" component={IncidentDetail} />
            <Route path="/incidents" component={Incidents} />
            <Route path="/contacts" component={Contacts} />
            <Route path="/deadman" component={DeadmanRules} />
            <Route path="/settings" component={Settings} />
            <Route path="/audit-log" component={AuditLog} />
            <Route component={NotFound} />
          </Switch>
        </Layout>
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AppContent />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;