import { 
  useGetVault, 
  useGetVaultFiles, 
  useAddVaultFile, 
  useDeleteFile,
  useUpdateVault,
  getGetVaultQueryKey,
  getGetVaultFilesQueryKey
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Database, FileText, ArrowLeft, Upload, Lock, Unlock, Trash2, ShieldAlert, FileImage, FileAudio, FileVideo, FileCode, FileType } from "lucide-react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Link, useParams, useLocation } from "wouter";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { formatDate } from "@/lib/format";

export default function VaultDetail() {
  const { id } = useParams();
  const vaultId = parseInt(id || "0", 10);
  const [, setLocation] = useLocation();

  const { data: vault, isLoading: isVaultLoading } = useGetVault(vaultId, {
    query: { enabled: !!vaultId, queryKey: getGetVaultQueryKey(vaultId) }
  });

  const { data: files, isLoading: isFilesLoading } = useGetVaultFiles(vaultId, {
    query: { enabled: !!vaultId, queryKey: getGetVaultFilesQueryKey(vaultId) }
  });

  const queryClient = useQueryClient();
  const { toast } = useToast();
  const addFile = useAddVaultFile();
  const deleteFile = useDeleteFile();
  const updateVault = useUpdateVault();

  const [isAddFileOpen, setIsAddFileOpen] = useState(false);
  const [fileName, setFileName] = useState("");
  const [fileType, setFileType] = useState("document");
  
  const handleAddFile = () => {
    addFile.mutate({
      vaultId,
      data: {
        name: fileName,
        fileType: fileType as any
      }
    }, {
      onSuccess: () => {
        toast({ title: "File Added", description: "Evidence logged to vault." });
        queryClient.invalidateQueries({ queryKey: getGetVaultFilesQueryKey(vaultId) });
        queryClient.invalidateQueries({ queryKey: getGetVaultQueryKey(vaultId) });
        setIsAddFileOpen(false);
        setFileName("");
        setFileType("document");
      },
      onError: (err) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      }
    });
  };

  const handleDeleteFile = (fileId: number) => {
    deleteFile.mutate({ id: fileId }, {
      onSuccess: () => {
        toast({ title: "File Deleted", description: "Evidence removed." });
        queryClient.invalidateQueries({ queryKey: getGetVaultFilesQueryKey(vaultId) });
        queryClient.invalidateQueries({ queryKey: getGetVaultQueryKey(vaultId) });
      }
    });
  };

  const toggleLock = () => {
    if (!vault) return;
    updateVault.mutate({
      id: vaultId,
      data: { isLocked: !vault.isLocked }
    }, {
      onSuccess: () => {
        toast({ 
          title: vault.isLocked ? "Vault Unlocked" : "Vault Locked",
          description: vault.isLocked ? "Files can now be modified." : "Vault is sealed. Files cannot be modified."
        });
        queryClient.invalidateQueries({ queryKey: getGetVaultQueryKey(vaultId) });
      }
    });
  };

  const getFileIcon = (type: string) => {
    switch(type) {
      case 'image': case 'screenshot': return <FileImage className="h-5 w-5 text-blue-500" />;
      case 'audio': return <FileAudio className="h-5 w-5 text-purple-500" />;
      case 'video': return <FileVideo className="h-5 w-5 text-red-500" />;
      case 'legal': case 'pdf': return <FileCode className="h-5 w-5 text-amber-500" />;
      default: return <FileType className="h-5 w-5 text-muted-foreground" />;
    }
  };

  if (isVaultLoading) {
    return <div className="space-y-6 max-w-5xl mx-auto"><Skeleton className="h-48 w-full" /><Skeleton className="h-96 w-full" /></div>;
  }

  if (!vault) {
    return <div className="text-center py-20 font-mono text-muted-foreground uppercase">Vault not found or access denied</div>;
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-500 max-w-5xl mx-auto">
      <Link href="/vaults">
        <Button variant="ghost" size="sm" className="mb-2 -ml-3 text-muted-foreground font-mono tracking-widest hover:text-foreground">
          <ArrowLeft className="mr-2 h-4 w-4" />
          RETURN TO VAULTS
        </Button>
      </Link>

      <div className={`flex flex-col md:flex-row justify-between items-start md:items-center gap-6 bg-card border rounded-lg p-6 relative overflow-hidden ${vault.isLocked ? 'border-primary/50' : 'border-border'}`}>
        {vault.isLocked && <div className="absolute top-0 left-0 w-1.5 h-full bg-primary" />}
        
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="text-3xl font-bold tracking-tight">{vault.name}</h1>
            <Badge variant="outline" className="font-mono uppercase tracking-widest text-[10px] border-border">{vault.category}</Badge>
            <Badge variant={vault.status === 'active' ? 'default' : 'secondary'} className="font-mono uppercase tracking-widest text-[10px]">
              {vault.status}
            </Badge>
          </div>
          <p className="text-muted-foreground max-w-2xl text-sm leading-relaxed">{vault.description || "No description provided."}</p>
          <div className="text-xs font-mono text-muted-foreground pt-2">
            INITIALIZED: {formatDate(vault.createdAt)}
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto shrink-0">
          <Button 
            variant={vault.isLocked ? "default" : "outline"} 
            className={`gap-2 font-bold tracking-widest w-full sm:w-auto h-12 ${vault.isLocked ? 'bg-primary text-primary-foreground hover:bg-primary/90' : ''}`}
            onClick={toggleLock}
          >
            {vault.isLocked ? <Lock className="h-4 w-4" /> : <Unlock className="h-4 w-4" />}
            {vault.isLocked ? "VAULT SEALED" : "SEAL VAULT"}
          </Button>
        </div>
      </div>

      <Card className="border-border bg-card shadow-sm">
        <CardHeader className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-border/50 pb-4 gap-4">
          <div>
            <CardTitle className="flex items-center gap-2 text-xl">
              <Database className="h-5 w-5 text-primary" />
              Evidence Repository
            </CardTitle>
            <CardDescription className="mt-1">All files securely stored in this vault</CardDescription>
          </div>
          
          <Dialog open={isAddFileOpen} onOpenChange={setIsAddFileOpen}>
            <DialogTrigger asChild>
              <Button disabled={vault.isLocked} className="gap-2 font-bold tracking-widest">
                <Upload className="h-4 w-4" />
                SECURE FILE
              </Button>
            </DialogTrigger>
            <DialogContent className="border-border">
              <DialogHeader>
                <DialogTitle className="text-primary font-mono uppercase tracking-widest flex items-center gap-2">
                  <Upload className="h-5 w-5" /> Secure Evidence
                </DialogTitle>
                <DialogDescription>
                  Upload and encrypt a new file into this vault.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="fileName" className="font-mono text-xs uppercase tracking-widest">Description / Label</Label>
                  <Input 
                    id="fileName" 
                    value={fileName}
                    onChange={(e) => setFileName(e.target.value)}
                    placeholder="e.g. Threatening voicemail, Screenshot of messages"
                    className="bg-background"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="fileType" className="font-mono text-xs uppercase tracking-widest">Data Type</Label>
                  <Select value={fileType} onValueChange={setFileType}>
                    <SelectTrigger className="bg-background">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="document">Document / Text</SelectItem>
                      <SelectItem value="image">Image / Photo</SelectItem>
                      <SelectItem value="audio">Audio Recording</SelectItem>
                      <SelectItem value="video">Video Recording</SelectItem>
                      <SelectItem value="screenshot">Screenshot</SelectItem>
                      <SelectItem value="pdf">PDF Document</SelectItem>
                      <SelectItem value="legal">Legal Document</SelectItem>
                      <SelectItem value="other">Other / Binary</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={() => setIsAddFileOpen(false)} className="font-mono tracking-widest">CANCEL</Button>
                <Button onClick={handleAddFile} disabled={!fileName || addFile.isPending} className="font-bold tracking-widest">
                  {addFile.isPending ? "ENCRYPTING..." : "SECURE TO VAULT"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent className="p-0">
          {vault.isLocked && (
            <div className="p-4 bg-primary/10 text-primary border-b border-primary/20 flex items-center gap-3 text-sm font-mono tracking-wide font-bold">
              <ShieldAlert className="h-5 w-5 shrink-0" />
              SYSTEM LOCK ACTIVE. VAULT CONTENTS ARE READ-ONLY AND CANNOT BE ALTERED OR REMOVED.
            </div>
          )}

          {isFilesLoading ? (
            <div className="p-6 space-y-4">
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-16 w-full" />
            </div>
          ) : !files || files.length === 0 ? (
            <div className="text-center py-20 bg-background/30">
              <FileText className="h-16 w-16 text-muted-foreground/20 mx-auto mb-4" />
              <h3 className="text-lg font-bold text-foreground">Repository Empty</h3>
              <p className="text-sm text-muted-foreground mt-1 max-w-sm mx-auto">No evidence has been secured in this vault yet.</p>
            </div>
          ) : (
            <div className="divide-y divide-border/50">
              {files.map(file => (
                <div key={file.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-4 sm:p-5 hover:bg-muted/10 transition-colors gap-4">
                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-md bg-secondary border border-border/50 shrink-0">
                      {getFileIcon(file.fileType)}
                    </div>
                    <div>
                      <h4 className="font-bold text-base">{file.name}</h4>
                      <div className="flex flex-wrap items-center gap-3 mt-2 text-xs font-mono">
                        <span className="uppercase bg-background border border-border/50 text-muted-foreground px-2 py-0.5 rounded tracking-widest font-bold">
                          {file.fileType}
                        </span>
                        <span className="text-muted-foreground">{formatDate(file.createdAt)}</span>
                        {file.sizeBytes && <span className="text-muted-foreground opacity-70">{(file.sizeBytes / 1024).toFixed(1)} KB</span>}
                      </div>
                    </div>
                  </div>
                  {!vault.isLocked && (
                    <Button 
                      variant="ghost" 
                      className="text-muted-foreground hover:text-destructive hover:bg-destructive/10 self-end sm:self-auto font-mono text-xs tracking-widest shrink-0"
                      onClick={() => handleDeleteFile(file.id)}
                      disabled={deleteFile.isPending}
                    >
                      <Trash2 className="h-4 w-4 mr-2" /> DELETE
                    </Button>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}