import { 
  useGetDeadmanRules, 
  useCreateDeadmanRule, 
  useDeleteDeadmanRule,
  useRenewDeadmanRule,
  getGetDeadmanRulesQueryKey 
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Skull, Plus, Clock, ShieldAlert, Trash2, RefreshCw, AlertTriangle } from "lucide-react";
import { useState, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { formatDate, formatTimeAgo } from "@/lib/format";

export default function DeadmanRules() {
  const { data: rules, isLoading } = useGetDeadmanRules({
    query: { queryKey: getGetDeadmanRulesQueryKey() }
  });

  const queryClient = useQueryClient();
  const { toast } = useToast();
  const createRule = useCreateDeadmanRule();
  const deleteRule = useDeleteDeadmanRule();
  const renewRule = useRenewDeadmanRule();

  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [name, setName] = useState("");
  const [triggerAfterHours, setTriggerAfterHours] = useState("168"); // 7 days default
  const [releaseTarget, setReleaseTarget] = useState("trusted_circle");
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 60000); // update every minute
    return () => clearInterval(timer);
  }, []);

  const handleCreate = () => {
    createRule.mutate({
      data: {
        name,
        triggerAfterHours: parseInt(triggerAfterHours, 10),
        releaseTarget: releaseTarget as any,
        gracePeriodMinutes: 120 // Default 2h warning
      }
    }, {
      onSuccess: () => {
        toast({ title: "Rule Created", description: "Deadman switch armed." });
        queryClient.invalidateQueries({ queryKey: getGetDeadmanRulesQueryKey() });
        setIsCreateOpen(false);
        setName("");
        setTriggerAfterHours("168");
      },
      onError: (err) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      }
    });
  };

  const handleRenew = (id: number) => {
    renewRule.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Timer Renewed", description: "Deadman switch reset successfully." });
        queryClient.invalidateQueries({ queryKey: getGetDeadmanRulesQueryKey() });
      }
    });
  };

  const handleDelete = (id: number) => {
    deleteRule.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Rule Removed" });
        queryClient.invalidateQueries({ queryKey: getGetDeadmanRulesQueryKey() });
      }
    });
  };

  const getUrgency = (triggerAt: string | null) => {
    if (!triggerAt) return { text: "UNKNOWN", urgent: false };
    const diffHours = (new Date(triggerAt).getTime() - now.getTime()) / (1000 * 60 * 60);
    return {
      urgent: diffHours < 6 && diffHours > 0,
      expired: diffHours <= 0
    };
  };

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-24 w-full" /><Skeleton className="h-64 w-full" /></div>;

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-5xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-border/50 pb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2 flex items-center gap-3">
            <Skull className="h-8 w-8 text-primary" />
            Deadman Rules
          </h1>
          <p className="text-muted-foreground font-mono text-sm">Automated evidence release protocols</p>
        </div>

        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 font-bold tracking-widest">
              <Plus className="h-4 w-4" /> NEW RULE
            </Button>
          </DialogTrigger>
          <DialogContent className="border-border">
            <DialogHeader>
              <DialogTitle className="text-primary font-mono tracking-widest uppercase flex items-center gap-2">
                <Skull className="h-5 w-5" /> Configure Deadman Switch
              </DialogTitle>
              <DialogDescription>
                If you do not log in and renew this rule before the timer expires, evidence will be automatically released.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="font-mono text-xs uppercase tracking-widest">Rule Name</Label>
                <Input id="name" value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Master Release Protocol" className="bg-background" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="hours" className="font-mono text-xs uppercase tracking-widest">Trigger Timer (Hours)</Label>
                <Input id="hours" type="number" value={triggerAfterHours} onChange={e => setTriggerAfterHours(e.target.value)} className="bg-background" />
                <p className="text-xs text-muted-foreground font-mono">Default is 168 hours (7 days)</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="target" className="font-mono text-xs uppercase tracking-widest">Release Target</Label>
                <Select value={releaseTarget} onValueChange={setReleaseTarget}>
                  <SelectTrigger className="bg-background"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="trusted_circle">Trusted Circle Contacts</SelectItem>
                    <SelectItem value="attorney">Attorney Contacts Only</SelectItem>
                    <SelectItem value="journalist">Journalist Contacts Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setIsCreateOpen(false)} className="font-mono tracking-widest">CANCEL</Button>
              <Button onClick={handleCreate} disabled={!name || createRule.isPending} className="font-bold tracking-widest">
                ARM SWITCH
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="bg-primary/5 border-primary/20 shadow-none">
        <CardContent className="p-5 flex flex-col sm:flex-row items-start gap-4">
          <div className="p-3 bg-primary/20 rounded-full shrink-0">
            <ShieldAlert className="h-6 w-6 text-primary" />
          </div>
          <div className="text-sm">
            <strong className="text-primary block mb-1 tracking-widest font-mono uppercase">Warning: Automated Release</strong>
            <p className="text-muted-foreground leading-relaxed">
              These rules execute automatically if you do not log in to renew them. Use these for extreme contingencies. Once evidence is released to external parties, it cannot be undone.
            </p>
          </div>
        </CardContent>
      </Card>

      {!rules || rules.length === 0 ? (
        <Card className="bg-card/30 border-dashed border-2">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <Skull className="h-16 w-16 text-muted-foreground mb-6 opacity-30" />
            <h3 className="text-lg font-bold mb-2">No Deadman Rules Configured</h3>
            <p className="text-muted-foreground text-sm max-w-sm">
              Create a rule to automatically distribute evidence if you are incapacitated or captured.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {rules.map(rule => {
            const urgency = getUrgency(rule.willTriggerAt);
            return (
              <Card key={rule.id} className={`
                border overflow-hidden relative shadow-sm
                ${rule.status === 'active' ? 'bg-card' : 'bg-muted/10'}
                ${urgency.urgent ? 'border-destructive/50 shadow-[0_0_20px_rgba(220,38,38,0.15)]' : 'border-border'}
              `}>
                {rule.status === 'active' && <div className={`absolute top-0 left-0 w-1.5 h-full ${urgency.urgent ? 'bg-destructive' : 'bg-primary'}`} />}
                
                <CardHeader className="pb-4 border-b border-border/50">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <CardTitle className="text-xl font-bold flex items-center gap-2">
                        {rule.name}
                        {urgency.urgent && <AlertTriangle className="h-5 w-5 text-destructive animate-pulse" />}
                      </CardTitle>
                      <div className="flex flex-wrap gap-2 mt-2">
                        <Badge variant={rule.status === 'active' ? 'default' : 'secondary'} className="uppercase font-mono text-[10px] tracking-wider">
                          {rule.status}
                        </Badge>
                        <Badge variant="outline" className="uppercase font-mono text-[10px] tracking-wider border-border">
                          TARGET: {rule.releaseTarget.replace('_', ' ')}
                        </Badge>
                      </div>
                    </div>
                    
                    {rule.status === 'active' && (
                      <Button 
                        size="lg"
                        className={`font-bold tracking-widest h-12 w-full md:w-auto ${urgency.urgent ? 'bg-destructive hover:bg-destructive text-destructive-foreground animate-pulse' : 'bg-primary hover:bg-primary/90 text-primary-foreground'}`}
                        onClick={() => handleRenew(rule.id)}
                        disabled={renewRule.isPending}
                      >
                        <RefreshCw className={`h-5 w-5 mr-2 ${renewRule.isPending ? 'animate-spin' : ''}`} /> 
                        RENEW TIMER
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="py-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-background p-4 rounded-md border border-border/50 flex items-center gap-4">
                      <div className="p-3 bg-secondary rounded-full">
                        <Clock className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div>
                        <div className="text-xs font-mono tracking-widest text-muted-foreground mb-1">INTERVAL</div>
                        <div className="font-bold text-lg">{rule.triggerAfterHours} Hours</div>
                      </div>
                    </div>
                    
                    <div className={`md:col-span-2 bg-background p-4 rounded-md border flex items-center gap-4 ${urgency.urgent ? 'border-destructive/30 bg-destructive/5' : 'border-border/50'}`}>
                      <div className={`p-3 rounded-full ${urgency.urgent ? 'bg-destructive/20' : 'bg-primary/10'}`}>
                        <Skull className={`h-5 w-5 ${urgency.urgent ? 'text-destructive' : 'text-primary'}`} />
                      </div>
                      <div>
                        <div className={`text-xs font-mono tracking-widest mb-1 ${urgency.urgent ? 'text-destructive font-bold' : 'text-primary'}`}>
                          TRIGGERING
                        </div>
                        <div className="flex flex-col sm:flex-row sm:items-baseline gap-2">
                          <span className={`font-bold text-xl ${urgency.urgent ? 'text-destructive' : 'text-foreground'}`}>
                            {rule.willTriggerAt ? formatTimeAgo(rule.willTriggerAt) : "Unknown"}
                          </span>
                          <span className="text-sm font-mono text-muted-foreground">
                            ({formatDate(rule.willTriggerAt)})
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-6 text-xs font-mono text-muted-foreground border-t border-border/50 pt-4 flex justify-between">
                    <span>LAST RENEWED: {formatDate(rule.lastRenewedAt)}</span>
                  </div>
                </CardContent>
                <CardFooter className="pt-0 justify-end border-t border-border/50 p-4">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="text-destructive hover:bg-destructive/10 hover:text-destructive font-mono text-xs tracking-widest"
                    onClick={() => handleDelete(rule.id)}
                  >
                    <Trash2 className="h-4 w-4 mr-2" /> DISARM & DELETE
                  </Button>
                </CardFooter>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}