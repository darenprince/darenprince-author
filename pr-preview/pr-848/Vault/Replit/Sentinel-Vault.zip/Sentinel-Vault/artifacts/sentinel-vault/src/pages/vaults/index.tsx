import { useGetVaults, useCreateVault, getGetVaultsQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Database, Plus, Search, Shield, Lock, Unlock, FileText, User, AlertTriangle, Briefcase, Calendar, Hash } from "lucide-react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { formatDate } from "@/lib/format";

export default function Vaults() {
  const { data: vaults, isLoading } = useGetVaults({
    query: { queryKey: getGetVaultsQueryKey() }
  });
  
  const createVault = useCreateVault();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("other");
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const handleCreate = () => {
    createVault.mutate({
      data: {
        name,
        description,
        category: category as any,
        isLocked: false
      }
    }, {
      onSuccess: () => {
        toast({ title: "Vault Created", description: "Secure storage initialized." });
        queryClient.invalidateQueries({ queryKey: getGetVaultsQueryKey() });
        setIsCreateOpen(false);
        setName("");
        setDescription("");
        setCategory("other");
      },
      onError: (err) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      }
    });
  };

  const filteredVaults = vaults?.filter(v => {
    const matchesSearch = v.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          (v.description && v.description.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesStatus = statusFilter === "all" || v.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getCategoryConfig = (cat: string) => {
    switch(cat) {
      case 'person': return { icon: User, color: 'bg-blue-500/20 text-blue-500 border-blue-500/30' };
      case 'threat': return { icon: AlertTriangle, color: 'bg-destructive/20 text-destructive border-destructive/30' };
      case 'case': return { icon: Briefcase, color: 'bg-primary/20 text-primary border-primary/30' };
      case 'event': return { icon: Calendar, color: 'bg-purple-500/20 text-purple-500 border-purple-500/30' };
      case 'pattern': return { icon: Hash, color: 'bg-amber-500/20 text-amber-500 border-amber-500/30' };
      default: return { icon: Database, color: 'bg-secondary text-foreground border-border' };
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-12 w-1/3" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1,2,3,4,5,6].map(i => <Skeleton key={i} className="h-48" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-6xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-border/50 pb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2 flex items-center gap-3">
            <Database className="h-8 w-8 text-primary" />
            Evidence Vaults
          </h1>
          <p className="text-muted-foreground font-mono text-sm">Secure compartmentalized storage archives</p>
        </div>

        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 font-bold tracking-widest h-12 px-6">
              <Plus className="h-4 w-4" /> NEW VAULT
            </Button>
          </DialogTrigger>
          <DialogContent className="border-border bg-card">
            <DialogHeader>
              <DialogTitle className="text-primary font-mono tracking-widest uppercase flex items-center gap-2">
                <Database className="h-5 w-5" /> Initialize Vault
              </DialogTitle>
              <DialogDescription>
                Create a new secure compartment for evidence collection and organization.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-5 py-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="font-mono text-xs uppercase tracking-widest">Vault Name</Label>
                <Input 
                  id="name" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Case 204A, Threat Actor X"
                  className="bg-background"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="category" className="font-mono text-xs uppercase tracking-widest">Category</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger className="bg-background">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="person">Person of Interest</SelectItem>
                    <SelectItem value="threat">Threat Actor</SelectItem>
                    <SelectItem value="case">Legal Case</SelectItem>
                    <SelectItem value="event">Specific Event</SelectItem>
                    <SelectItem value="pattern">Pattern of Behavior</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="description" className="font-mono text-xs uppercase tracking-widest">Description (Optional)</Label>
                <Textarea 
                  id="description" 
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Details about the contents or purpose of this vault..."
                  className="bg-background min-h-[100px]"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setIsCreateOpen(false)} className="font-mono tracking-widest">CANCEL</Button>
              <Button onClick={handleCreate} disabled={!name || createVault.isPending} className="font-bold tracking-widest">
                {createVault.isPending ? "INITIALIZING..." : "INITIALIZE VAULT"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 bg-card p-4 border rounded-lg shadow-sm">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search vault contents..." 
            className="pl-9 bg-background h-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-[200px] bg-background h-10 font-mono text-sm">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">ALL STATUSES</SelectItem>
            <SelectItem value="active">ACTIVE</SelectItem>
            <SelectItem value="sealed">SEALED</SelectItem>
            <SelectItem value="released">RELEASED</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {!filteredVaults || filteredVaults.length === 0 ? (
        <div className="text-center py-20 border border-dashed rounded-lg bg-card/30">
          <Database className="h-16 w-16 text-muted-foreground/30 mx-auto mb-6" />
          <h3 className="text-xl font-bold mb-2">No Vaults Found</h3>
          <p className="text-muted-foreground text-sm max-w-sm mx-auto">
            {searchTerm ? "No vaults match your search criteria." : "You haven't initialized any evidence vaults yet. Create one to begin storing files securely."}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVaults.map(vault => {
            const config = getCategoryConfig(vault.category);
            const CatIcon = config.icon;
            
            return (
              <Link key={vault.id} href={`/vaults/${vault.id}`}>
                <Card className="hover:border-primary/50 hover:shadow-md transition-all duration-300 cursor-pointer h-full group border-border relative overflow-hidden flex flex-col bg-card">
                  <div className="absolute top-0 left-0 w-full h-1 bg-border group-hover:bg-primary/80 transition-colors" />
                  
                  <CardHeader className="pb-4 border-b border-border/50">
                    <div className="flex justify-between items-start mb-3">
                      <div className={`p-2 rounded-md border ${config.color}`}>
                        <CatIcon className="h-5 w-5" />
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        {vault.isLocked ? (
                          <div className="flex items-center gap-1 text-primary text-xs font-mono font-bold">
                            <Lock className="h-3 w-3" /> LOCKED
                          </div>
                        ) : (
                          <div className="flex items-center gap-1 text-muted-foreground text-xs font-mono">
                            <Unlock className="h-3 w-3" /> OPEN
                          </div>
                        )}
                        <Badge 
                          variant={vault.status === 'active' ? 'default' : 'secondary'} 
                          className="font-mono text-[10px] uppercase tracking-wider"
                        >
                          {vault.status}
                        </Badge>
                      </div>
                    </div>
                    <CardTitle className="text-xl line-clamp-1 group-hover:text-primary transition-colors">{vault.name}</CardTitle>
                  </CardHeader>
                  
                  <CardContent className="pt-4 flex-1 flex flex-col justify-between">
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-6 min-h-[40px]">
                      {vault.description || "No description provided."}
                    </p>
                    
                    <div className="flex justify-between items-center bg-background/50 p-3 rounded-md border border-border/50 mt-auto">
                      <div className="flex items-center gap-2 text-sm font-bold font-mono">
                        <FileText className="h-4 w-4 text-primary" />
                        <span>{vault.fileCount} FILES</span>
                      </div>
                      <div className="text-xs text-muted-foreground font-mono">
                        {formatDate(vault.createdAt)}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}