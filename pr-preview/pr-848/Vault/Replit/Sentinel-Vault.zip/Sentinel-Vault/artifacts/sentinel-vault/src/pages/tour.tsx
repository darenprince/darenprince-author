import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  X,
  ChevronLeft,
  ChevronRight,
  Volume2,
  VolumeX,
  Loader2,
  ShieldAlert,
  Database,
  FileText,
  Timer,
  Users2,
  Radio,
  Skull,
  Video,
  Key,
  HeartHandshake,
  Mic,
  Waves,
  Lock,
  Shield,
  Eye,
  AlertTriangle,
  Clock,
  Fingerprint,
  Siren,
  FileCheck,
  type LucideIcon,
} from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { useTTS } from "@/hooks/use-tts";
import shieldLogo from "@assets/F1B418FA-4D83-4684-9599-1CF1D20306A4_1774910006252.png";

interface Slide {
  title: string;
  narration: string;
  desc: string;
  points: string[];
  icon: LucideIcon;
  accentIcons: LucideIcon[];
  gradient: string;
  visual: "shield" | "grid" | "pulse" | "orbit" | "wave" | "vault" | "radar" | "stream" | "lock" | "heart";
}

const SLIDES: Slide[] = [
  {
    title: "Welcome to Sentinel Vault",
    narration:
      "Sentinel Vault is your personal black box for human survival. This is not an ordinary safety app. It was built for the moments ordinary apps fail — when you are scared, moving, isolated, or seconds away from losing control of your situation.",
    desc: "Your personal black box for human survival. This is not an ordinary safety app. Sentinel Vault assumes the stakes are real — that you may be scared, moving, isolated, or seconds away from losing control of your situation.",
    points: ["Built for real-world instability", "Works across any device", "Your truth survives"],
    icon: ShieldAlert,
    accentIcons: [Shield, Eye, Lock],
    gradient: "from-orange-500/20 via-amber-500/10 to-transparent",
    visual: "shield",
  },
  {
    title: "Evidence Vaults",
    narration:
      "Organize everything that matters into secure, compartmentalized vaults. Group your evidence by person, threat, legal case, or specific event. Every file becomes part of a survivable narrative — documents, audio, video, screenshots, IDs.",
    desc: "Organize everything that matters into secure, compartmentalized vaults. Group your evidence by person, threat, legal case, specific event, or patterns of behavior. Every file becomes part of a survivable narrative.",
    points: ["Documents, audio, video, screenshots, IDs", "Multiple vaults by context", "Timeline-organized archives"],
    icon: Database,
    accentIcons: [Lock, FileCheck, Shield],
    gradient: "from-blue-500/20 via-cyan-500/10 to-transparent",
    visual: "vault",
  },
  {
    title: "Incident Records",
    narration:
      "Create structured incident entries that build a chronological record of what happened, when it happened, who was involved, and how it escalated. This is your living case file — it remembers what trauma makes you forget.",
    desc: "Create structured incident entries that build a chronological record of what happened, when, who was involved, and how it escalated. This is your living case file — it remembers what trauma makes you forget.",
    points: ["Severity classification", "Status tracking", "Links to vault evidence"],
    icon: FileText,
    accentIcons: [AlertTriangle, Clock, Eye],
    gradient: "from-yellow-500/20 via-orange-500/10 to-transparent",
    visual: "grid",
  },
  {
    title: "Timed Check-ins",
    narration:
      "Arm a safety interval before any dangerous meeting, travel, or encounter. If you do not confirm safe return in time, Sentinel Vault escalates according to your preset instructions. Your silence becomes a signal.",
    desc: "Arm a safety interval before any dangerous meeting, travel, or encounter. If you don't confirm safe return in time, Sentinel Vault escalates according to your preset instructions. Silence becomes a signal.",
    points: ["Customizable intervals", "Missed check-ins trigger alerts", "Multiple active sessions"],
    icon: Timer,
    accentIcons: [Clock, AlertTriangle, Siren],
    gradient: "from-emerald-500/20 via-green-500/10 to-transparent",
    visual: "pulse",
  },
  {
    title: "Your Trusted Circle",
    narration:
      "Not everyone in your life needs to know everything. Define who receives SOS alerts, who gets notified of missed check-ins, and who receives evidence releases — all separately, by role. You control every disclosure.",
    desc: "Not everyone in your life needs to know everything. Define who receives SOS alerts, who gets notified of missed check-ins, and who receives evidence releases — all separately, by role.",
    points: ["Family, attorneys, advocates, journalists", "Role-based routing", "You control every disclosure"],
    icon: Users2,
    accentIcons: [Shield, Fingerprint, Lock],
    gradient: "from-violet-500/20 via-purple-500/10 to-transparent",
    visual: "orbit",
  },
  {
    title: "SOS Distress Signal",
    narration:
      "When you need help right now, the SOS trigger notifies your trusted contacts immediately with your location, status, and selected evidence. It was designed to be activated under pressure, when seconds matter.",
    desc: "When you need help right now, the SOS trigger notifies your trusted contacts immediately with your location, status, and selected evidence. Designed to be activated under pressure.",
    points: ["One-tap emergency broadcast", "Location-aware", "Configurable recipients"],
    icon: Radio,
    accentIcons: [Siren, AlertTriangle, Eye],
    gradient: "from-red-500/20 via-rose-500/10 to-transparent",
    visual: "radar",
  },
  {
    title: "Deadman Release",
    narration:
      "Configure evidence to automatically release to a trusted contact, attorney, or journalist if you go silent past a deadline. Even if you lose access to your device, your evidence survives.",
    desc: "Configure evidence to automatically release to a trusted contact, attorney, or journalist if you go silent past a deadline. Even if you lose access to your device, your evidence survives.",
    points: ["Configurable trigger windows", "Staged release with grace periods", "Multiple release targets"],
    icon: Skull,
    accentIcons: [Clock, Lock, FileCheck],
    gradient: "from-amber-500/20 via-yellow-500/10 to-transparent",
    visual: "wave",
  },
  {
    title: "Live Capture",
    narration:
      "Preserve active incidents in real time. Audio and video sessions are captured in rolling segments so interruption does not erase what was recorded. If your device is taken, uploaded segments survive.",
    desc: "Preserve active incidents in real time. Audio and video sessions are captured in rolling segments so interruption doesn't erase what was recorded. If your device is taken, uploaded segments survive.",
    points: ["Rolling segment capture", "Survivable sessions", "Witness access support"],
    icon: Video,
    accentIcons: [Mic, Eye, Shield],
    gradient: "from-cyan-500/20 via-blue-500/10 to-transparent",
    visual: "stream",
  },
  {
    title: "Secure Access",
    narration:
      "Sentinel Vault is built around the principle that access failure is safety failure. Your account is your lifeline — protected with hardened authentication and designed for continuity under coercive conditions.",
    desc: "Sentinel Vault is built around the principle that access failure is safety failure. Your account is your lifeline — protected with hardened authentication and designed for continuity under coercive conditions.",
    points: ["Strong authentication", "Session management", "Designed for instability"],
    icon: Key,
    accentIcons: [Fingerprint, Lock, Shield],
    gradient: "from-indigo-500/20 via-violet-500/10 to-transparent",
    visual: "lock",
  },
  {
    title: "You Are Not Alone",
    narration:
      "Sentinel Vault exists for people the system often fails — survivors, witnesses, activists, the targeted. If something happens to you, your truth should not disappear with you. Your evidence matters. Your story matters.",
    desc: "Sentinel Vault exists for people the system often fails: survivors, witnesses, activists, the targeted. If something happens to you, your truth should not disappear with you. Your evidence matters. Your story matters.",
    points: ["Built for real consequences", "Designed for the vulnerable", "Your guardian is always armed"],
    icon: HeartHandshake,
    accentIcons: [Shield, Eye, HeartHandshake],
    gradient: "from-orange-500/20 via-red-500/10 to-transparent",
    visual: "heart",
  },
];

const SLIDE_DURATION = 25000;

function FloatingIcon({ icon: Icon, delay, x, y, size = 20 }: { icon: LucideIcon; delay: number; x: string; y: string; size?: number }) {
  return (
    <motion.div
      className="absolute text-primary/20"
      style={{ left: x, top: y }}
      initial={{ opacity: 0, scale: 0 }}
      animate={{
        opacity: [0, 0.4, 0.2, 0.4, 0],
        scale: [0.5, 1, 0.8, 1, 0.5],
        y: [0, -20, -10, -25, 0],
      }}
      transition={{ duration: 8, delay, repeat: Infinity, ease: "easeInOut" }}
    >
      <Icon size={size} />
    </motion.div>
  );
}

function ShieldVisual() {
  return (
    <div className="relative w-full h-full flex items-center justify-center">
      <motion.div
        className="absolute inset-0 bg-gradient-radial from-primary/15 via-transparent to-transparent rounded-full"
        animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.6, 0.3] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute w-[120%] h-[120%] border border-primary/10 rounded-full"
        animate={{ rotate: 360 }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
      />
      <motion.div
        className="absolute w-[90%] h-[90%] border border-primary/5 rounded-full"
        animate={{ rotate: -360 }}
        transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
      />
      <motion.img
        src={shieldLogo}
        alt="Sentinel Shield"
        className="w-48 h-48 md:w-56 md:h-56 object-contain relative z-10 drop-shadow-[0_0_40px_rgba(234,88,12,0.3)]"
        animate={{ y: [0, -8, 0] }}
        transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
      />
    </div>
  );
}

function PulseVisual({ icon: Icon }: { icon: LucideIcon }) {
  return (
    <div className="relative w-full h-full flex items-center justify-center">
      {[0, 1, 2].map((i) => (
        <motion.div
          key={i}
          className="absolute border border-primary/20 rounded-full"
          style={{ width: `${60 + i * 25}%`, height: `${60 + i * 25}%` }}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: [0, 0.5, 0], scale: [0.8, 1.1, 0.8] }}
          transition={{ duration: 3, delay: i * 0.8, repeat: Infinity, ease: "easeInOut" }}
        />
      ))}
      <motion.div
        className="bg-card/60 backdrop-blur-md border border-border/50 rounded-full w-32 h-32 md:w-40 md:h-40 flex items-center justify-center shadow-2xl relative z-10"
        animate={{ scale: [1, 1.05, 1] }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
      >
        <Icon className="w-16 h-16 md:w-20 md:h-20 text-primary" strokeWidth={1.2} />
      </motion.div>
    </div>
  );
}

function GridVisual({ icon: Icon }: { icon: LucideIcon }) {
  return (
    <div className="relative w-full h-full flex items-center justify-center">
      <div className="absolute inset-0 grid grid-cols-4 grid-rows-4 gap-2 opacity-20">
        {Array.from({ length: 16 }).map((_, i) => (
          <motion.div
            key={i}
            className="border border-primary/30 rounded-lg"
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.5, 0.2] }}
            transition={{ duration: 2, delay: i * 0.1, repeat: Infinity, repeatType: "reverse" }}
          />
        ))}
      </div>
      <motion.div
        className="bg-card/60 backdrop-blur-md border border-border/50 rounded-2xl w-32 h-32 md:w-40 md:h-40 flex items-center justify-center shadow-2xl relative z-10"
        animate={{ rotate: [0, 2, -2, 0] }}
        transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
      >
        <Icon className="w-16 h-16 md:w-20 md:h-20 text-primary" strokeWidth={1.2} />
      </motion.div>
    </div>
  );
}

function OrbitVisual({ icon: Icon, accentIcons }: { icon: LucideIcon; accentIcons: LucideIcon[] }) {
  return (
    <div className="relative w-full h-full flex items-center justify-center">
      <motion.div
        className="absolute w-[80%] h-[80%] border border-primary/10 rounded-full"
        animate={{ rotate: 360 }}
        transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
      >
        {accentIcons.map((AccIcon, i) => {
          const angle = (i * 120) * (Math.PI / 180);
          return (
            <motion.div
              key={i}
              className="absolute bg-card/80 border border-primary/30 rounded-full w-10 h-10 flex items-center justify-center"
              style={{
                left: `calc(50% + ${Math.cos(angle) * 45}% - 20px)`,
                top: `calc(50% + ${Math.sin(angle) * 45}% - 20px)`,
              }}
            >
              <AccIcon className="w-5 h-5 text-primary" />
            </motion.div>
          );
        })}
      </motion.div>
      <motion.div
        className="bg-card/60 backdrop-blur-md border border-border/50 rounded-full w-28 h-28 md:w-36 md:h-36 flex items-center justify-center shadow-2xl relative z-10"
        animate={{ scale: [1, 1.03, 1] }}
        transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
      >
        <Icon className="w-14 h-14 md:w-18 md:h-18 text-primary" strokeWidth={1.2} />
      </motion.div>
    </div>
  );
}

function RadarVisual({ icon: Icon }: { icon: LucideIcon }) {
  return (
    <div className="relative w-full h-full flex items-center justify-center">
      {[0, 1, 2, 3].map((i) => (
        <div key={i} className="absolute border border-primary/10 rounded-full"
          style={{ width: `${40 + i * 18}%`, height: `${40 + i * 18}%` }} />
      ))}
      <motion.div
        className="absolute w-[92%] h-[92%]"
        animate={{ rotate: 360 }}
        transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
      >
        <div className="absolute top-1/2 left-1/2 w-1/2 h-0.5 origin-left bg-gradient-to-r from-primary/60 to-transparent" />
      </motion.div>
      {[
        { x: "65%", y: "30%", delay: 0 },
        { x: "25%", y: "60%", delay: 1.5 },
        { x: "70%", y: "70%", delay: 3 },
      ].map((dot, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 bg-primary rounded-full"
          style={{ left: dot.x, top: dot.y }}
          animate={{ opacity: [0, 1, 0], scale: [0, 1.5, 0] }}
          transition={{ duration: 2, delay: dot.delay, repeat: Infinity }}
        />
      ))}
      <div className="bg-card/60 backdrop-blur-md border border-border/50 rounded-full w-24 h-24 md:w-32 md:h-32 flex items-center justify-center shadow-2xl relative z-10">
        <Icon className="w-12 h-12 md:w-16 md:h-16 text-primary" strokeWidth={1.2} />
      </div>
    </div>
  );
}

function WaveVisual({ icon: Icon }: { icon: LucideIcon }) {
  return (
    <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
      <svg className="absolute inset-0 w-full h-full" viewBox="0 0 200 200" preserveAspectRatio="none">
        {[0, 1, 2].map((i) => (
          <motion.path
            key={i}
            d={`M0,${100 + i * 15} Q50,${80 + i * 15} 100,${100 + i * 15} T200,${100 + i * 15}`}
            fill="none"
            stroke="hsl(25 90% 50%)"
            strokeWidth="0.5"
            strokeOpacity={0.15 - i * 0.03}
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 3, delay: i * 0.3, repeat: Infinity, repeatType: "reverse" }}
          />
        ))}
      </svg>
      <motion.div
        className="bg-card/60 backdrop-blur-md border border-border/50 rounded-2xl w-32 h-32 md:w-40 md:h-40 flex items-center justify-center shadow-2xl relative z-10"
        animate={{ y: [0, -6, 0] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
      >
        <Icon className="w-16 h-16 md:w-20 md:h-20 text-primary" strokeWidth={1.2} />
      </motion.div>
    </div>
  );
}

function StreamVisual({ icon: Icon }: { icon: LucideIcon }) {
  return (
    <div className="relative w-full h-full flex items-center justify-center">
      {Array.from({ length: 5 }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute h-0.5 bg-gradient-to-r from-transparent via-primary/30 to-transparent"
          style={{ width: `${30 + i * 12}%`, top: `${20 + i * 15}%` }}
          animate={{ x: [-100, 100], opacity: [0, 0.6, 0] }}
          transition={{ duration: 3, delay: i * 0.5, repeat: Infinity, ease: "linear" }}
        />
      ))}
      <motion.div
        className="absolute w-3 h-3 bg-primary rounded-full shadow-[0_0_15px_rgba(234,88,12,0.5)]"
        animate={{
          x: ["-80px", "80px", "-80px"],
          y: ["-40px", "40px", "-40px"],
        }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="bg-card/60 backdrop-blur-md border border-border/50 rounded-2xl w-32 h-32 md:w-40 md:h-40 flex items-center justify-center shadow-2xl relative z-10"
        animate={{ scale: [1, 1.02, 1] }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
      >
        <Icon className="w-16 h-16 md:w-20 md:h-20 text-primary" strokeWidth={1.2} />
      </motion.div>
    </div>
  );
}

function LockVisual({ icon: Icon }: { icon: LucideIcon }) {
  return (
    <div className="relative w-full h-full flex items-center justify-center">
      <motion.div
        className="absolute w-[70%] h-[70%] border-2 border-primary/15 rounded-2xl"
        animate={{ borderColor: ["hsl(25 90% 50% / 0.1)", "hsl(25 90% 50% / 0.3)", "hsl(25 90% 50% / 0.1)"] }}
        transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute w-[85%] h-[85%] border border-primary/5 rounded-3xl"
        animate={{ rotate: [0, 3, -3, 0] }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
      />
      {[0, 1, 2, 3].map((i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-primary/40 rounded-full"
          style={{
            left: `${20 + i * 20}%`,
            top: i % 2 === 0 ? "15%" : "85%",
          }}
          animate={{ opacity: [0, 1, 0] }}
          transition={{ duration: 1.5, delay: i * 0.3, repeat: Infinity }}
        />
      ))}
      <motion.div
        className="bg-card/60 backdrop-blur-md border border-border/50 rounded-2xl w-32 h-32 md:w-40 md:h-40 flex items-center justify-center shadow-2xl relative z-10"
        animate={{ y: [0, -4, 0] }}
        transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
      >
        <Icon className="w-16 h-16 md:w-20 md:h-20 text-primary" strokeWidth={1.2} />
      </motion.div>
    </div>
  );
}

function HeartVisual({ icon: Icon }: { icon: LucideIcon }) {
  return (
    <div className="relative w-full h-full flex items-center justify-center">
      <motion.div
        className="absolute inset-0 bg-gradient-radial from-primary/10 via-transparent to-transparent rounded-full"
        animate={{ scale: [1, 1.3, 1], opacity: [0.2, 0.5, 0.2] }}
        transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
      />
      {Array.from({ length: 8 }).map((_, i) => {
        const angle = (i * 45) * (Math.PI / 180);
        return (
          <motion.div
            key={i}
            className="absolute w-1.5 h-1.5 bg-primary/30 rounded-full"
            style={{
              left: `calc(50% + ${Math.cos(angle) * 42}%)`,
              top: `calc(50% + ${Math.sin(angle) * 42}%)`,
            }}
            animate={{ opacity: [0.2, 0.8, 0.2], scale: [0.5, 1.2, 0.5] }}
            transition={{ duration: 2, delay: i * 0.25, repeat: Infinity }}
          />
        );
      })}
      <motion.div
        className="bg-card/60 backdrop-blur-md border border-border/50 rounded-full w-32 h-32 md:w-40 md:h-40 flex items-center justify-center shadow-2xl relative z-10"
        animate={{ scale: [1, 1.06, 1, 1.04, 1] }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
      >
        <Icon className="w-16 h-16 md:w-20 md:h-20 text-primary" strokeWidth={1.2} />
      </motion.div>
    </div>
  );
}

function VaultVisual({ icon: Icon }: { icon: LucideIcon }) {
  return (
    <div className="relative w-full h-full flex items-center justify-center">
      <motion.div
        className="absolute w-[80%] h-[80%] border border-primary/10 rounded-lg"
        animate={{ borderColor: ["hsl(25 90% 50% / 0.05)", "hsl(25 90% 50% / 0.2)", "hsl(25 90% 50% / 0.05)"] }}
        transition={{ duration: 4, repeat: Infinity }}
      />
      <motion.div
        className="absolute w-[65%] h-[65%] border border-primary/15 rounded-lg"
        animate={{ rotate: [0, 90, 180, 270, 360] }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
      />
      {[Lock, FileCheck, Shield].map((AccIcon, i) => (
        <motion.div
          key={i}
          className="absolute bg-card/80 border border-primary/20 rounded-lg w-10 h-10 flex items-center justify-center"
          style={{
            left: `${15 + i * 30}%`,
            top: i === 1 ? "15%" : "75%",
          }}
          animate={{ y: [0, -5, 0], opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 3, delay: i * 0.5, repeat: Infinity }}
        >
          <AccIcon className="w-5 h-5 text-primary/60" />
        </motion.div>
      ))}
      <motion.div
        className="bg-card/60 backdrop-blur-md border border-border/50 rounded-2xl w-32 h-32 md:w-40 md:h-40 flex items-center justify-center shadow-2xl relative z-10"
        animate={{ scale: [1, 1.02, 1] }}
        transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
      >
        <Icon className="w-16 h-16 md:w-20 md:h-20 text-primary" strokeWidth={1.2} />
      </motion.div>
    </div>
  );
}

function SlideVisual({ slide }: { slide: Slide }) {
  const visualMap: Record<string, React.FC<any>> = {
    shield: ShieldVisual,
    pulse: PulseVisual,
    grid: GridVisual,
    orbit: OrbitVisual,
    radar: RadarVisual,
    wave: WaveVisual,
    stream: StreamVisual,
    lock: LockVisual,
    heart: HeartVisual,
    vault: VaultVisual,
  };
  const VisualComponent = visualMap[slide.visual] || PulseVisual;
  return <VisualComponent icon={slide.icon} accentIcons={slide.accentIcons} />;
}

export default function TourPage() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [, setLocation] = useLocation();
  const { speak, stop, preload, toggleMute, isLoading, isPlaying, isMuted, engine } = useTTS();
  const hasSpokenRef = useRef<Set<number>>(new Set());
  const contentRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const autoScrollRef = useRef<number | null>(null);

  const slide = SLIDES[currentIndex];

  const startAutoScroll = useCallback(() => {
    if (autoScrollRef.current) cancelAnimationFrame(autoScrollRef.current);

    const el = scrollContainerRef.current;
    if (!el) return;

    const checkAndScroll = () => {
      const maxScroll = el.scrollHeight - el.clientHeight;
      if (maxScroll <= 0) return;

      const scrollDelay = 3000;
      const startTime = Date.now();
      const scrollDuration = Math.max((SLIDE_DURATION - scrollDelay - 2000), 4000);

      const animate = () => {
        const elapsed = Date.now() - startTime;
        if (elapsed < scrollDelay) {
          autoScrollRef.current = requestAnimationFrame(animate);
          return;
        }
        const scrollElapsed = elapsed - scrollDelay;
        const scrollProgress = Math.min(scrollElapsed / scrollDuration, 1);
        const eased = scrollProgress < 0.5
          ? 2 * scrollProgress * scrollProgress
          : 1 - Math.pow(-2 * scrollProgress + 2, 2) / 2;

        el.scrollTop = eased * maxScroll;

        if (scrollProgress < 1) {
          autoScrollRef.current = requestAnimationFrame(animate);
        }
      };

      autoScrollRef.current = requestAnimationFrame(animate);
    };

    setTimeout(checkAndScroll, 500);
  }, []);

  useEffect(() => {
    if (!isMuted && !hasSpokenRef.current.has(currentIndex)) {
      hasSpokenRef.current.add(currentIndex);
      speak(slide.narration);
    } else if (isMuted) {
      stop();
    }

    const nextIdx = currentIndex + 1;
    if (nextIdx < SLIDES.length) {
      const t = setTimeout(() => preload(SLIDES[nextIdx].narration), 3000);
      return () => clearTimeout(t);
    }
  }, [currentIndex, isMuted]);

  useEffect(() => {
    return () => stop();
  }, []);

  useEffect(() => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTop = 0;
    }
    if (autoScrollRef.current) {
      cancelAnimationFrame(autoScrollRef.current);
    }
    startAutoScroll();

    return () => {
      if (autoScrollRef.current) cancelAnimationFrame(autoScrollRef.current);
    };
  }, [currentIndex, startAutoScroll]);

  useEffect(() => {
    if (isPaused) return;
    setProgress(0);
    const startTime = Date.now();

    const timer = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const newProgress = (elapsed / SLIDE_DURATION) * 100;

      if (newProgress >= 100) {
        clearInterval(timer);
        if (currentIndex < SLIDES.length - 1) {
          setCurrentIndex((prev) => prev + 1);
        } else {
          stop();
          setLocation("/dashboard");
        }
      } else {
        setProgress(newProgress);
      }
    }, 50);

    return () => clearInterval(timer);
  }, [currentIndex, isPaused]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") {
        if (currentIndex < SLIDES.length - 1) setCurrentIndex((prev) => prev + 1);
      } else if (e.key === "ArrowLeft") {
        if (currentIndex > 0) setCurrentIndex((prev) => prev - 1);
      } else if (e.key === "Escape") {
        stop();
        setLocation("/dashboard");
      } else if (e.key === " ") {
        e.preventDefault();
        setIsPaused((p) => !p);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentIndex]);

  const AudioIcon = isMuted ? VolumeX : isLoading ? Loader2 : isPlaying ? Waves : Volume2;
  const engineLabel = engine === "chatterbox" ? "Chatterbox AI" : null;

  return (
    <div className="fixed inset-0 bg-background text-foreground flex flex-col z-50 overflow-hidden">
      <div className={`absolute inset-0 bg-gradient-radial ${slide.gradient} pointer-events-none transition-all duration-1000`} />

      <div className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, hsl(25 90% 50%) 0.5px, transparent 0.5px)`,
          backgroundSize: "40px 40px",
        }}
      />

      <FloatingIcon icon={slide.accentIcons[0]} delay={0} x="10%" y="20%" size={24} />
      <FloatingIcon icon={slide.accentIcons[1]} delay={2} x="85%" y="15%" size={18} />
      <FloatingIcon icon={slide.accentIcons[2]} delay={4} x="80%" y="75%" size={22} />
      <FloatingIcon icon={slide.icon} delay={1} x="15%" y="70%" size={16} />

      <div className="absolute top-0 left-0 right-0 z-20">
        <div className="h-1 bg-secondary/30 relative overflow-hidden">
          <motion.div
            className="absolute inset-y-0 left-0 bg-primary"
            style={{ width: `${progress}%` }}
            transition={{ duration: 0.05 }}
          />
          <motion.div
            className="absolute inset-y-0 left-0 bg-primary/50 blur-sm"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="flex justify-between items-center px-4 md:px-6 pt-3 pb-2">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleMute}
              className="text-muted-foreground hover:text-foreground h-9 w-9 hover:bg-primary/10"
              title={isMuted ? "Unmute narration" : "Mute narration"}
            >
              <AudioIcon className={`h-4 w-4 ${isLoading ? "animate-spin" : isPlaying && !isMuted ? "animate-pulse" : ""}`} />
            </Button>
            {!isMuted && engineLabel && (
              <span className="text-[10px] font-mono text-primary/60 uppercase tracking-widest hidden sm:block">
                {engineLabel}
              </span>
            )}
            {!isMuted && isLoading && (
              <span className="text-[10px] font-mono text-primary/80 uppercase tracking-widest hidden sm:block animate-pulse">
                Generating audio...
              </span>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsPaused((p) => !p)}
              className="text-muted-foreground hover:text-foreground text-xs font-mono tracking-wider hover:bg-primary/10 h-8"
            >
              {isPaused ? "RESUME" : "PAUSE"}
            </Button>
          </div>

          <span className="font-mono text-xs text-muted-foreground tracking-widest">
            {currentIndex + 1} / {SLIDES.length}
          </span>

          <Button
            variant="ghost"
            size="icon"
            onClick={() => { stop(); setLocation("/dashboard"); }}
            className="text-muted-foreground hover:text-foreground h-9 w-9 hover:bg-primary/10"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div
        ref={scrollContainerRef}
        className="flex-1 overflow-y-auto scroll-smooth mt-16 mb-16"
        style={{ scrollBehavior: "smooth" }}
      >
        <div ref={contentRef} className="min-h-full flex items-center justify-center px-6 md:px-12 py-8">
          <Button
            variant="ghost"
            size="icon"
            className="fixed left-3 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full hidden md:flex bg-card/50 backdrop-blur-sm border border-border/50 hover:bg-primary/10 hover:border-primary/30 z-30 transition-all"
            disabled={currentIndex === 0}
            onClick={() => setCurrentIndex((prev) => prev - 1)}
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>

          <Button
            variant="ghost"
            size="icon"
            className="fixed right-3 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full hidden md:flex bg-card/50 backdrop-blur-sm border border-border/50 hover:bg-primary/10 hover:border-primary/30 z-30 transition-all"
            disabled={currentIndex === SLIDES.length - 1}
            onClick={() => setCurrentIndex((prev) => prev + 1)}
          >
            <ChevronRight className="h-5 w-5" />
          </Button>

          <div className="max-w-5xl w-full grid md:grid-cols-2 gap-8 md:gap-16 items-center">
            <AnimatePresence mode="wait">
              <motion.div
                key={`visual-${currentIndex}`}
                initial={{ opacity: 0, scale: 0.8, x: -30 }}
                animate={{ opacity: 1, scale: 1, x: 0 }}
                exit={{ opacity: 0, scale: 0.9, x: 30 }}
                transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
                className="flex justify-center relative"
              >
                <div className="relative w-64 h-64 md:w-80 md:h-80">
                  <SlideVisual slide={slide} />
                </div>
              </motion.div>
            </AnimatePresence>

            <AnimatePresence mode="wait">
              <motion.div
                key={`content-${currentIndex}`}
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -30 }}
                transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
                className="space-y-6"
              >
                <motion.div
                  className="space-y-3"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.2 }}
                >
                  <div className="flex items-center gap-3">
                    <div className="h-px flex-1 bg-gradient-to-r from-primary/50 to-transparent max-w-16" />
                    <span className="font-mono text-[11px] text-primary uppercase tracking-[0.2em] font-semibold">
                      System {currentIndex + 1} of {SLIDES.length}
                    </span>
                  </div>
                  <h1 className="text-3xl md:text-5xl font-bold tracking-tight leading-tight">{slide.title}</h1>
                </motion.div>

                <motion.p
                  className="text-base md:text-lg text-muted-foreground leading-relaxed"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                >
                  {slide.desc}
                </motion.p>

                <motion.ul
                  className="space-y-3 pt-4 border-t border-border/30"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.6 }}
                >
                  {slide.points.map((point, i) => (
                    <motion.li
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.7 + i * 0.15, duration: 0.5 }}
                      className="flex items-center gap-3 text-sm md:text-base"
                    >
                      <motion.div
                        className="w-2 h-2 rounded-full bg-primary shrink-0 shadow-[0_0_8px_rgba(234,88,12,0.4)]"
                        animate={{ scale: [1, 1.3, 1] }}
                        transition={{ duration: 2, delay: i * 0.3, repeat: Infinity }}
                      />
                      <span className="font-mono text-sm tracking-wide">{point}</span>
                    </motion.li>
                  ))}
                </motion.ul>

                {isPlaying && !isMuted && (
                  <motion.div
                    className="flex items-center gap-2 pt-2"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.3 }}
                  >
                    <div className="flex items-center gap-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <motion.div
                          key={i}
                          className="w-0.5 bg-primary/60 rounded-full"
                          animate={{ height: [4, 12 + Math.random() * 8, 4] }}
                          transition={{ duration: 0.5 + Math.random() * 0.3, repeat: Infinity, delay: i * 0.1 }}
                        />
                      ))}
                    </div>
                    <span className="text-[10px] font-mono text-primary/50 uppercase tracking-widest ml-1">
                      Narrating
                    </span>
                  </motion.div>
                )}

                {currentIndex === SLIDES.length - 1 && (
                  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.2 }} className="pt-6">
                    <Button
                      size="lg"
                      className="w-full font-mono tracking-widest text-lg h-14 bg-primary hover:bg-primary/90 shadow-[0_0_30px_rgba(234,88,12,0.3)] hover:shadow-[0_0_40px_rgba(234,88,12,0.5)] transition-shadow"
                      onClick={() => { stop(); setLocation("/dashboard"); }}
                    >
                      ENTER SYSTEM
                    </Button>
                  </motion.div>
                )}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>

      <div className="flex justify-center gap-2 p-4 z-20 relative">
        {SLIDES.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrentIndex(i)}
            className={`transition-all duration-500 rounded-full ${
              i === currentIndex
                ? "w-8 h-2 bg-primary shadow-[0_0_10px_rgba(234,88,12,0.5)]"
                : i < currentIndex
                  ? "w-2 h-2 bg-primary/40"
                  : "w-2 h-2 bg-muted/50 hover:bg-primary/30"
            }`}
            aria-label={`Go to slide ${i + 1}`}
          />
        ))}
      </div>
    </div>
  );
}
