import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Shield, Key, Download, Trash2, Smartphone, Terminal, Server, LogOut } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const { toast } = useToast();

  const handleSave = () => {
    toast({
      title: "Configuration Saved",
      description: "System preferences have been updated and synced.",
    });
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-5xl mx-auto">
      <div className="border-b border-border/50 pb-6">
        <h1 className="text-3xl font-bold tracking-tight mb-2 flex items-center gap-3">
          <Terminal className="h-8 w-8 text-primary" />
          System Configuration
        </h1>
        <p className="text-muted-foreground font-mono text-sm">Security parameters, encryption keys, and account management</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-start">
        <div className="md:col-span-1 space-y-6">
          <div className="p-5 bg-card border border-border/50 rounded-lg shadow-sm font-mono text-sm flex flex-col gap-3 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full bg-primary" />
            <span className="text-muted-foreground uppercase tracking-widest text-[10px] font-bold">Active Session</span>
            <div className="text-lg font-bold text-foreground">Operator Primary</div>
            <div className="flex flex-col gap-1 mt-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">ID:</span>
                <span>OP-7729-ALPHA</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">STATUS:</span>
                <span className="text-primary font-bold">VERIFIED</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">UPTIME:</span>
                <span>4h 12m</span>
              </div>
            </div>
            
            <Button variant="outline" className="w-full mt-4 border-border/50 font-mono text-xs tracking-widest h-8" size="sm">
              <LogOut className="h-3 w-3 mr-2" /> TERMINATE
            </Button>
          </div>
          
          <div className="p-5 bg-secondary/30 border border-border/50 rounded-lg font-mono text-xs flex flex-col gap-3">
            <div className="flex items-center gap-2 text-muted-foreground uppercase tracking-widest font-bold mb-2">
              <Server className="h-4 w-4" /> Endpoint Info
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">NODE:</span>
              <span>us-west-secured-1</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">VERSION:</span>
              <span>v1.0.4-stable</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">ENCRYPTION:</span>
              <span>AES-256-GCM</span>
            </div>
          </div>
        </div>

        <div className="md:col-span-2 space-y-6">
          <Card className="border-border shadow-sm">
            <CardHeader className="bg-muted/10 border-b border-border/50">
              <CardTitle className="text-lg flex items-center gap-2 font-mono uppercase tracking-widest">
                <Shield className="h-5 w-5 text-primary" />
                Access Controls
              </CardTitle>
              <CardDescription>Manage your primary authentication methods.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-6">
              <div className="space-y-3">
                <Label htmlFor="master-pass" className="font-mono text-xs uppercase tracking-widest font-bold">Master Decryption Key</Label>
                <div className="flex gap-3">
                  <Input id="master-pass" type="password" placeholder="••••••••••••••••" className="bg-background h-12" />
                  <Button variant="secondary" className="h-12 font-mono tracking-widest px-6">ROTATE</Button>
                </div>
                <p className="text-xs text-muted-foreground font-mono">Used to encrypt vaults. If lost, data cannot be recovered.</p>
              </div>
              
              <div className="pt-6 border-t border-border/50 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <h4 className="font-bold text-sm">Two-Factor Authentication</h4>
                  <p className="text-xs text-muted-foreground mt-1 max-w-sm">Require a time-based code from an authenticator app when signing in from new devices.</p>
                </div>
                <Button variant="outline" size="sm" className="gap-2 font-mono tracking-widest shrink-0 border-primary/50 text-primary hover:bg-primary hover:text-primary-foreground">
                  <Smartphone className="h-4 w-4" /> ENABLE 2FA
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border shadow-sm">
            <CardHeader className="bg-muted/10 border-b border-border/50">
              <CardTitle className="text-lg flex items-center gap-2 font-mono uppercase tracking-widest">
                <Key className="h-5 w-5 text-primary" />
                Cryptographic Keys
              </CardTitle>
              <CardDescription>Export your public keys for secure communications.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-6">
              <div className="space-y-2">
                <Label className="font-mono text-xs uppercase tracking-widest font-bold">Your Public PGP Block</Label>
                <div className="p-4 bg-background border border-border/50 rounded-md font-mono text-xs break-all text-muted-foreground select-all h-32 overflow-y-auto">
                  -----BEGIN PGP PUBLIC KEY BLOCK-----
                  <br/><br/>
                  mQINBGEa0O8BEADF3Yd0rB4GZf+V...
                  <br/>
                  [Key block redacted for display purposes. Click Export to download full block.]
                  <br/>
                  ...xT9kZ=
                  <br/>
                  =WxZp
                  <br/>
                  -----END PGP PUBLIC KEY BLOCK-----
                </div>
              </div>
              <div className="flex gap-3">
                <Button variant="outline" className="gap-2 font-mono tracking-widest">
                  <Download className="h-4 w-4" /> EXPORT BLOCK
                </Button>
                <Button variant="secondary" className="font-mono tracking-widest text-muted-foreground">GENERATE NEW PAIR</Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border-destructive/30 bg-destructive/5 shadow-none mt-8">
            <CardHeader className="border-b border-destructive/10 pb-4">
              <CardTitle className="text-lg text-destructive flex items-center gap-2 font-mono uppercase tracking-widest font-bold">
                <Trash2 className="h-5 w-5" />
                Scorched Earth
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <p className="text-sm mb-6 text-foreground/80 leading-relaxed border-l-2 border-destructive/50 pl-4">
                This protocol will permanently overwrite and destroy all vaults, files, incident logs, and account data across all nodes. This action is immediate, irrevocable, and stops all active timers and deadman rules.
              </p>
              <Button variant="destructive" size="lg" className="font-black tracking-widest w-full sm:w-auto px-8 h-14 bg-destructive hover:bg-red-700">
                INITIATE DATA BURN
              </Button>
            </CardContent>
          </Card>

          <div className="flex justify-end pt-8 pb-12">
            <Button onClick={handleSave} size="lg" className="font-bold tracking-widest h-14 px-12 text-lg w-full md:w-auto shadow-lg">
              APPLY CONFIGURATION
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}