import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { motion, useScroll, useMotionValueEvent, AnimatePresence } from "framer-motion";
import {
  Shield, Database, Clock, Users, Radio, Skull, FileText,
  ArrowRight, ChevronRight, Lock, Eye, Zap, Globe
} from "lucide-react";
import appIcon from "@assets/F1B418FA-4D83-4684-9599-1CF1D20306A4_1774910006252.png";
import { useState, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";

const TICKER_ITEMS = ["Capture", "Preserve", "Signal", "Release"];

export default function LandingPage() {
  const [, navigate] = useLocation();
  const [navScrolled, setNavScrolled] = useState(false);
  const { toast } = useToast();
  const { scrollY } = useScroll();

  useMotionValueEvent(scrollY, "change", (latest) => {
    setNavScrolled(latest > 40);
  });

  const handleEnterVault = useCallback(() => {
    toast({
      title: "Initializing Sentinel Vault",
      description: "Loading your command center...",
      duration: 2000,
    });
    setTimeout(() => navigate("/dashboard"), 300);
  }, [navigate, toast]);

  const handleWatchTour = useCallback(() => {
    toast({
      title: "Starting Product Tour",
      description: "10 slides with audio narration.",
      duration: 2000,
    });
    setTimeout(() => navigate("/tour"), 300);
  }, [navigate, toast]);

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">

      {/* Sticky Nav */}
      <motion.nav
        animate={{
          backgroundColor: navScrolled ? "hsl(222 47% 5% / 0.95)" : "hsl(222 47% 7% / 0.7)",
          borderBottomColor: navScrolled ? "hsl(220 14% 18% / 1)" : "hsl(220 14% 18% / 0.4)",
          backdropFilter: navScrolled ? "blur(20px)" : "blur(8px)",
        }}
        transition={{ duration: 0.3 }}
        style={{ borderBottomWidth: 1, borderBottomStyle: "solid" }}
        className="fixed top-0 left-0 right-0 z-50 px-6 py-3"
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <a href="#hero" className="flex items-center gap-3 group cursor-pointer">
            <img src={appIcon} alt="Sentinel Vault" className="h-8 w-8 object-contain group-hover:scale-110 transition-transform duration-300" />
            <span className="font-bold tracking-[0.2em] text-primary uppercase text-sm hidden sm:block">Sentinel Vault</span>
          </a>
          <div className="flex items-center gap-2">
            <a href="#features">
              <Button variant="ghost" size="sm" className="font-mono text-xs uppercase text-muted-foreground hover:text-foreground hidden md:flex">
                Features
              </Button>
            </a>
            <Button variant="ghost" size="sm" onClick={handleWatchTour} className="font-mono text-xs uppercase text-muted-foreground hover:text-foreground hidden sm:flex">
              Product Tour
            </Button>
            <Button size="sm" onClick={handleEnterVault} className="font-mono font-bold tracking-wider uppercase gap-1.5 shadow-[0_0_20px_hsl(25_90%_50%_/_0.25)] hover:shadow-[0_0_30px_hsl(25_90%_50%_/_0.4)] transition-all duration-300">
              Enter App <ChevronRight className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      </motion.nav>

      {/* Hero */}
      <section id="hero" className="relative pt-24 pb-0 overflow-hidden">
        {/* Background grid pattern */}
        <div className="absolute inset-0 pointer-events-none" style={{
          backgroundImage: "radial-gradient(hsl(220 14% 60% / 0.07) 1px, transparent 1px)",
          backgroundSize: "28px 28px"
        }} />
        {/* Radial glow behind logo */}
        <div className="absolute left-1/4 top-1/2 -translate-y-1/2 w-96 h-96 bg-primary/10 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute right-1/4 top-1/3 w-64 h-64 bg-orange-600/5 rounded-full blur-[100px] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-6 min-h-[calc(100vh-96px)] flex items-center">
          <div className="grid lg:grid-cols-2 gap-12 xl:gap-20 items-center w-full py-16">
            {/* Logo */}
            <motion.div
              initial={{ opacity: 0, x: -60, scale: 0.9 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
              className="flex justify-center lg:justify-end order-2 lg:order-1"
            >
              <div className="relative">
                <motion.div
                  animate={{ scale: [1, 1.08, 1], opacity: [0.15, 0.25, 0.15] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute inset-[-20%] bg-primary rounded-full blur-[80px]"
                />
                <motion.img
                  src={appIcon}
                  alt="Sentinel Shield"
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
                  className="w-72 h-72 md:w-[420px] md:h-[420px] object-contain drop-shadow-2xl relative z-10"
                />
              </div>
            </motion.div>

            {/* Text + CTAs */}
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
              className="space-y-7 text-center lg:text-left order-1 lg:order-2"
            >
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-primary/30 bg-primary/10 text-primary font-mono text-xs uppercase tracking-widest"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                System Armed &amp; Ready
              </motion.div>

              <h1 className="text-5xl md:text-6xl lg:text-6xl xl:text-7xl font-bold tracking-tight leading-[1.05]">
                Your Evidence{" "}
                <span className="text-foreground/70">Survives.</span>
                <br />
                <span className="text-primary">Your Signal</span>
                <br />
                Gets Out.
              </h1>

              <p className="text-lg text-muted-foreground max-w-lg mx-auto lg:mx-0 leading-relaxed">
                A personal black box for human survival. Built for whistleblowers, survivors,
                journalists, and activists — for the moments ordinary apps fail.
              </p>

              <div className="flex flex-col sm:flex-row gap-3 justify-center lg:justify-start pt-2">
                <Button
                  size="lg"
                  onClick={handleEnterVault}
                  className="w-full sm:w-auto font-mono text-sm tracking-wider px-8 gap-2 shadow-[0_0_25px_hsl(25_90%_50%_/_0.3)] hover:shadow-[0_0_40px_hsl(25_90%_50%_/_0.5)] transition-all duration-300 group"
                >
                  ENTER THE VAULT
                  <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform duration-200" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={handleWatchTour}
                  className="w-full sm:w-auto font-mono text-sm tracking-wider px-8 border-border/70 hover:border-primary/50 hover:bg-primary/5 transition-all duration-300"
                >
                  WATCH THE TOUR
                </Button>
              </div>

              <div className="flex items-center gap-6 justify-center lg:justify-start pt-2 text-muted-foreground/60">
                {[
                  { icon: Lock, label: "End-to-end encrypted" },
                  { icon: Eye, label: "No tracking" },
                  { icon: Zap, label: "Always armed" },
                ].map(({ icon: Icon, label }) => (
                  <div key={label} className="flex items-center gap-1.5 text-xs font-mono">
                    <Icon className="h-3 w-3" />
                    <span>{label}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>

        {/* Ticker — block element, no overlap */}
        <div className="border-y border-border/40 bg-card/60 overflow-hidden py-3.5">
          <motion.div
            className="flex whitespace-nowrap font-mono text-xs tracking-[0.2em] text-muted-foreground uppercase"
            animate={{ x: ["0%", "-50%"] }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          >
            {[...Array(6)].map((_, i) => (
              <div key={i} className="flex items-center">
                {TICKER_ITEMS.map((item, j) => (
                  <span key={j} className={`mx-6 ${item === "Signal" ? "text-primary font-bold" : ""}`}>
                    {item}
                    <span className="mx-4 opacity-30">•</span>
                  </span>
                ))}
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Feature Grid */}
      <section id="features" className="py-28 relative">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <p className="font-mono text-xs text-primary uppercase tracking-[0.25em] mb-4">Core Systems</p>
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Built for the worst-case scenario</h2>
            <p className="text-muted-foreground mt-4 max-w-xl mx-auto leading-relaxed">
              Six interlocking systems that work together to capture, preserve, and broadcast your evidence — even without you.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {FEATURES.map((feature, i) => (
              <FeatureCard key={feature.title} {...feature} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* Stats strip */}
      <section className="py-16 border-y border-border/40 bg-card/40">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { value: "6", label: "Interlocking Systems" },
              { value: "0", label: "Third-party Trackers" },
              { value: "100%", label: "Local Processing" },
              { value: "24/7", label: "Always Armed" },
            ].map(({ value, label }, i) => (
              <motion.div
                key={label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.5 }}
                className="space-y-1"
              >
                <div className="text-4xl font-bold text-primary font-mono">{value}</div>
                <div className="text-xs font-mono text-muted-foreground uppercase tracking-widest">{label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission Statement */}
      <section id="mission" className="py-32 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none" style={{
          background: "radial-gradient(ellipse at center, hsl(25 90% 50% / 0.04) 0%, transparent 70%)"
        }} />
        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="max-w-4xl mx-auto px-6 text-center"
        >
          <div className="flex justify-center mb-10">
            <div className="relative">
              <div className="absolute inset-0 bg-primary/20 blur-xl rounded-full" />
              <img src={appIcon} alt="Shield" className="w-14 h-14 object-contain relative z-10 opacity-80" />
            </div>
          </div>
          <blockquote className="text-2xl md:text-4xl lg:text-5xl font-bold leading-tight tracking-tight text-foreground/90">
            "If something happens to you, your evidence, context, and emergency instructions should{" "}
            <span className="text-primary">not disappear with you.</span>"
          </blockquote>
          <p className="mt-8 text-muted-foreground font-mono text-sm tracking-widest uppercase">
            The Sentinel Vault Principle
          </p>
        </motion.div>
      </section>

      {/* For Who */}
      <section id="for-who" className="py-24 bg-card/30 border-y border-border/40">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <p className="font-mono text-xs text-primary uppercase tracking-[0.25em] mb-3">Who it's for</p>
            <h2 className="text-2xl md:text-3xl font-bold">Designed for the targeted</h2>
          </motion.div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {WHO_ITEMS.map(({ label, icon: Icon }, i) => (
              <motion.div
                key={label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08, duration: 0.5 }}
                whileHover={{ scale: 1.03, borderColor: "hsl(25 90% 50% / 0.6)" }}
                className="p-5 border border-border/50 bg-background rounded-xl flex flex-col items-center justify-center gap-3 cursor-default transition-colors duration-200 hover:bg-primary/5"
              >
                <div className="w-9 h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                  <Icon className="w-4 h-4" />
                </div>
                <span className="font-mono text-xs tracking-wide text-muted-foreground text-center leading-tight">{label}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-28 relative overflow-hidden text-center px-6">
        <div className="absolute inset-0 pointer-events-none" style={{
          background: "radial-gradient(ellipse at 50% 100%, hsl(25 90% 50% / 0.08) 0%, transparent 60%)"
        }} />
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="max-w-2xl mx-auto relative z-10 space-y-6"
        >
          <p className="font-mono text-xs text-primary uppercase tracking-[0.25em]">Ready when you are</p>
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight">Your guardian is armed.</h2>
          <p className="text-muted-foreground text-lg max-w-md mx-auto leading-relaxed">
            Enter the vault and configure your first evidence archive, safety interval, or trusted contact.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center pt-4">
            <Button
              size="lg"
              onClick={handleEnterVault}
              className="font-mono tracking-wider px-10 text-base gap-2 shadow-[0_0_30px_hsl(25_90%_50%_/_0.3)] hover:shadow-[0_0_50px_hsl(25_90%_50%_/_0.5)] transition-all duration-300 group"
            >
              ENTER THE VAULT
              <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform duration-200" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={handleWatchTour}
              className="font-mono tracking-wider px-10 text-base border-border/70 hover:border-primary/50 hover:bg-primary/5 transition-all duration-300"
            >
              WATCH THE TOUR
            </Button>
          </div>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-border/40 bg-card/20">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img src={appIcon} alt="Logo" className="w-6 h-6 object-contain opacity-50 grayscale" />
            <span className="font-mono text-xs text-muted-foreground/60 uppercase tracking-widest">Sentinel Vault</span>
          </div>
          <p className="font-mono text-xs text-muted-foreground/50 uppercase tracking-widest">
            Capture &bull; Preserve &bull; Signal &bull; Release
          </p>
          <p className="font-mono text-xs text-muted-foreground/40">&copy; {new Date().getFullYear()}</p>
        </div>
      </footer>
    </div>
  );
}

const FEATURES = [
  {
    icon: Database,
    title: "Evidence Vaults",
    desc: "Secure compartmentalized storage organized by person, threat, legal case, or event. Every file becomes part of a survivable narrative.",
    highlight: false,
  },
  {
    icon: Clock,
    title: "Timed Check-ins",
    desc: "Arm safety intervals before dangerous meetings or travel. Missed check-ins automatically escalate to your trusted contacts.",
    highlight: false,
  },
  {
    icon: Users,
    title: "Trusted Circle",
    desc: "Role-based disclosure routing to family, attorneys, advocates, and journalists. You control every disclosure, separately.",
    highlight: false,
  },
  {
    icon: Radio,
    title: "SOS Distress Signal",
    desc: "One-tap emergency broadcast to your entire trusted circle with location, status, and selected evidence attached.",
    highlight: true,
  },
  {
    icon: Skull,
    title: "Deadman Release",
    desc: "Evidence automatically releases if you go silent past a deadline. Even without device access, your evidence survives.",
    highlight: false,
  },
  {
    icon: FileText,
    title: "Incident Records",
    desc: "Structured chronological documentation of what happened, who was involved, and how it escalated — building your living case file.",
    highlight: false,
  },
];

const WHO_ITEMS = [
  { label: "Whistleblowers", icon: Globe },
  { label: "Survivors", icon: Shield },
  { label: "Journalists", icon: FileText },
  { label: "Activists", icon: Zap },
  { label: "Legal Witnesses", icon: Eye },
  { label: "Anyone Under Threat", icon: Lock },
];

function FeatureCard({
  icon: Icon,
  title,
  desc,
  highlight,
  index,
}: {
  icon: any;
  title: string;
  desc: string;
  highlight: boolean;
  index: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.55, delay: index * 0.07, ease: [0.16, 1, 0.3, 1] }}
      whileHover={{ y: -4, transition: { duration: 0.2 } }}
      className={`group relative p-7 border rounded-xl bg-background flex flex-col gap-4 transition-colors duration-300 overflow-hidden ${
        highlight
          ? "border-primary/40 shadow-[0_0_40px_hsl(25_90%_50%_/_0.08)]"
          : "border-border/60 hover:border-border"
      }`}
    >
      {highlight && (
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent pointer-events-none" />
      )}
      {/* Top accent line */}
      <div className={`absolute top-0 left-0 right-0 h-px transition-all duration-300 ${
        highlight ? "bg-primary/60" : "bg-transparent group-hover:bg-border"
      }`} />

      <div className={`w-11 h-11 rounded-lg flex items-center justify-center flex-shrink-0 transition-all duration-300 ${
        highlight ? "bg-primary/15 text-primary" : "bg-secondary/80 text-muted-foreground group-hover:bg-primary/10 group-hover:text-primary"
      }`}>
        <Icon className="w-5 h-5" />
      </div>
      <h3 className={`text-lg font-bold transition-colors duration-300 ${
        highlight ? "text-primary" : "group-hover:text-foreground"
      }`}>
        {title}
      </h3>
      <p className="text-muted-foreground text-sm leading-relaxed flex-1">{desc}</p>
      <div className={`flex items-center gap-1.5 text-xs font-mono transition-all duration-300 opacity-0 group-hover:opacity-100 ${
        highlight ? "text-primary" : "text-muted-foreground"
      }`}>
        <span>Learn more</span>
        <ChevronRight className="h-3 w-3" />
      </div>
    </motion.div>
  );
}
