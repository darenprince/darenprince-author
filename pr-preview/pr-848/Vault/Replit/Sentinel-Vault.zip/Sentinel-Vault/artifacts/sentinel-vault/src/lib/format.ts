import { format, formatDistanceToNow } from "date-fns";

export function formatDate(dateStr: string | undefined | null) {
  if (!dateStr) return "-";
  return format(new Date(dateStr), "MMM d, yyyy HH:mm");
}

export function formatTimeAgo(dateStr: string | undefined | null) {
  if (!dateStr) return "-";
  return formatDistanceToNow(new Date(dateStr), { addSuffix: true });
}
