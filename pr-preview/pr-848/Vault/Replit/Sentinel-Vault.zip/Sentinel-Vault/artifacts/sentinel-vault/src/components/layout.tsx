import { Link, useLocation } from "wouter";
import { 
  Database, 
  AlertTriangle, 
  Timer, 
  Users2, 
  Settings2, 
  Radio, 
  Hourglass,
  Menu,
  X,
  LayoutDashboard,
  ChevronUp,
  HelpCircle,
  Compass,
  Info,
  UserCircle,
  ScrollText
} from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import appIcon from "@assets/F1B418FA-4D83-4684-9599-1CF1D20306A4_1774910006252.png";

const MAIN_NAV = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/vaults", label: "Evidence Vaults", icon: Database },
  { href: "/incidents", label: "Incidents", icon: AlertTriangle },
  { href: "/checkins", label: "Check-ins", icon: Timer },
  { href: "/contacts", label: "Trusted Circle", icon: Users2 },
  { href: "/deadman", label: "Deadman Rules", icon: Hourglass },
  { href: "/audit-log", label: "Audit Log", icon: ScrollText },
];

const SETTINGS_NAV = [
  { href: "/settings", label: "Settings", icon: Settings2 },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const isSosActive = location === "/sos";

  return (
    <div className="flex min-h-screen w-full bg-background text-foreground font-sans">
      <div className="lg:hidden fixed top-0 left-0 right-0 h-14 border-b border-border/60 bg-background/95 backdrop-blur-md z-50 flex items-center justify-between px-4">
        <div className="flex items-center gap-2.5">
          <img src={appIcon} alt="Sentinel Vault" className="h-7 w-7 object-contain" />
          <span className="text-primary font-semibold tracking-wide text-sm">Sentinel Vault</span>
        </div>
        <Button variant="ghost" size="icon" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
          {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </div>

      <aside className={`
        fixed inset-y-0 left-0 z-40 w-[260px] bg-sidebar border-r border-sidebar-border transform transition-transform duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] lg:translate-x-0 flex flex-col
        ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="h-14 flex items-center px-5 border-b border-sidebar-border gap-2.5 flex-shrink-0">
          <img src={appIcon} alt="Sentinel Vault" className="h-8 w-8 object-contain" />
          <div className="flex flex-col">
            <span className="text-primary font-semibold text-[13px] tracking-wide leading-tight">Sentinel Vault</span>
            <span className="text-[10px] font-mono text-sidebar-foreground/40 tracking-wider">SECURITY PLATFORM</span>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto py-4 px-3 flex flex-col gap-1">
          <div className="px-2 mb-1.5 text-[10px] font-mono uppercase tracking-[0.15em] text-sidebar-foreground/40 font-medium">Core Systems</div>
          <nav className="space-y-0.5">
            {MAIN_NAV.map((item) => {
              const isActive = location === item.href || (item.href !== "/dashboard" && location.startsWith(item.href));
              return (
                <Link key={item.href} href={item.href} onClick={() => setIsMobileMenuOpen(false)}>
                  <div className={`
                    flex items-center gap-2.5 px-2.5 py-2 rounded-md transition-all cursor-pointer text-[13px] font-medium
                    ${isActive 
                      ? 'bg-primary/12 text-primary shadow-[inset_0_0_0_1px_hsl(25_90%_50%_/_0.2)]' 
                      : 'text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-sidebar-foreground'}
                  `}>
                    <item.icon className={`h-[18px] w-[18px] flex-shrink-0 ${isActive ? 'text-primary' : ''}`} strokeWidth={isActive ? 2 : 1.75} />
                    {item.label}
                  </div>
                </Link>
              );
            })}
          </nav>

          <div className="mt-auto pt-4">
            <div className="px-2 mb-1.5 text-[10px] font-mono uppercase tracking-[0.15em] text-sidebar-foreground/40 font-medium">Preferences</div>
            <nav className="space-y-0.5">
              {SETTINGS_NAV.map((item) => {
                const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
                return (
                  <Link key={item.href} href={item.href} onClick={() => setIsMobileMenuOpen(false)}>
                    <div className={`
                      flex items-center gap-2.5 px-2.5 py-2 rounded-md transition-all cursor-pointer text-[13px] font-medium
                      ${isActive 
                        ? 'bg-primary/12 text-primary shadow-[inset_0_0_0_1px_hsl(25_90%_50%_/_0.2)]' 
                        : 'text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-sidebar-foreground'}
                    `}>
                      <item.icon className={`h-[18px] w-[18px] flex-shrink-0 ${isActive ? 'text-primary' : ''}`} strokeWidth={isActive ? 2 : 1.75} />
                      {item.label}
                    </div>
                  </Link>
                );
              })}
            </nav>
          </div>
        </div>

        <div className="p-3 border-t border-sidebar-border space-y-3">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="w-full justify-between px-2 h-10 text-[13px] hover:bg-sidebar-accent/50">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-sidebar-accent flex items-center justify-center">
                    <UserCircle className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <span className="font-medium">My Account</span>
                </div>
                <ChevronUp className="h-3.5 w-3.5 opacity-40" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 text-[13px] border-border bg-card">
              <Link href="/settings">
                <DropdownMenuItem className="cursor-pointer gap-2"><Settings2 className="h-4 w-4"/> Settings</DropdownMenuItem>
              </Link>
              <Link href="/tour">
                <DropdownMenuItem className="cursor-pointer gap-2"><Compass className="h-4 w-4"/> Product Tour</DropdownMenuItem>
              </Link>
              <DropdownMenuItem className="cursor-pointer gap-2"><HelpCircle className="h-4 w-4"/> Help & Support</DropdownMenuItem>
              <DropdownMenuItem className="cursor-pointer gap-2"><Info className="h-4 w-4"/> About Sentinel</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Link href="/sos" onClick={() => setIsMobileMenuOpen(false)}>
            <Button 
              variant="destructive" 
              className={`w-full h-11 text-sm font-bold tracking-wider flex items-center justify-center gap-2 transition-all rounded-lg ${
                isSosActive ? "sos-glow animate-pulse scale-[0.97]" : "hover:sos-glow shadow-md hover:shadow-lg"
              }`}
            >
              <Radio className={`h-4.5 w-4.5 ${isSosActive ? "" : "animate-pulse"}`} />
              SOS TRIGGER
            </Button>
          </Link>
        </div>
      </aside>

      <main className="flex-1 lg:pl-[260px] flex flex-col min-h-[100dvh] pt-14 lg:pt-0 relative z-0">
        <div className="flex-1 p-4 md:p-6 lg:p-8 max-w-[1400px] w-full mx-auto">
          {children}
        </div>
      </main>

      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-background/80 z-30 lg:hidden backdrop-blur-sm"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}
    </div>
  );
}
