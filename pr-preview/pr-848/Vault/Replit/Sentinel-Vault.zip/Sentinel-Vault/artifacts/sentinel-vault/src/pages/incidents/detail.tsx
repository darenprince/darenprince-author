import { 
  useGetIncident, 
  useUpdateIncident, 
  useDeleteIncident,
  getGetIncidentQueryKey,
  getGetIncidentsQueryKey
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { AlertTriangle, ArrowLeft, Calendar, MapPin, Users, Clock, Edit, Trash2, CheckCircle, Hash } from "lucide-react";
import { useState, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Link, useParams, useLocation } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { formatDate } from "@/lib/format";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function IncidentDetail() {
  const { id } = useParams();
  const incidentId = parseInt(id || "0", 10);
  const [, setLocation] = useLocation();

  const { data: incident, isLoading } = useGetIncident(incidentId, {
    query: { enabled: !!incidentId, queryKey: getGetIncidentQueryKey(incidentId) }
  });

  const queryClient = useQueryClient();
  const { toast } = useToast();
  const updateIncident = useUpdateIncident();
  const deleteIncident = useDeleteIncident();

  const [status, setStatus] = useState("");

  useEffect(() => {
    if (incident) {
      setStatus(incident.status);
    }
  }, [incident]);

  const handleStatusChange = (newStatus: string) => {
    setStatus(newStatus);
    updateIncident.mutate({
      id: incidentId,
      data: { status: newStatus as any }
    }, {
      onSuccess: () => {
        toast({ title: "Status Updated", description: `Incident is now marked as ${newStatus}` });
        queryClient.invalidateQueries({ queryKey: getGetIncidentQueryKey(incidentId) });
        queryClient.invalidateQueries({ queryKey: getGetIncidentsQueryKey() });
      }
    });
  };

  const handleDelete = () => {
    if (!confirm("CRITICAL WARNING: Are you sure you want to permanently delete this incident record? This cannot be undone and breaks continuity.")) return;
    
    deleteIncident.mutate({ id: incidentId }, {
      onSuccess: () => {
        toast({ title: "Incident Record Erased" });
        queryClient.invalidateQueries({ queryKey: getGetIncidentsQueryKey() });
        setLocation("/incidents");
      }
    });
  };

  const getSeverityBadge = (sev: string) => {
    switch(sev) {
      case 'critical': return 'bg-destructive text-destructive-foreground hover:bg-destructive/90';
      case 'high': return 'bg-primary text-primary-foreground hover:bg-primary/90';
      case 'medium': return 'bg-amber-500 text-amber-950 hover:bg-amber-500/90';
      case 'low': return 'bg-blue-500 text-white hover:bg-blue-500/90';
      default: return 'bg-secondary text-secondary-foreground';
    }
  };

  if (isLoading) return <div className="space-y-6 max-w-5xl mx-auto"><Skeleton className="h-48 w-full" /><Skeleton className="h-96 w-full" /></div>;
  if (!incident) return <div className="text-center py-20 font-mono uppercase tracking-widest text-muted-foreground">Incident Record Not Found</div>;

  return (
    <div className="space-y-6 animate-in fade-in duration-500 max-w-5xl mx-auto">
      <Link href="/incidents">
        <Button variant="ghost" size="sm" className="mb-2 -ml-3 text-muted-foreground font-mono tracking-widest hover:text-foreground">
          <ArrowLeft className="mr-2 h-4 w-4" />
          RETURN TO ARCHIVE
        </Button>
      </Link>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 border-b border-border/50 pb-6">
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <Badge className={`${getSeverityBadge(incident.severity)} uppercase font-bold tracking-widest text-[10px]`}>
              SEVERITY: {incident.severity}
            </Badge>
            <span className="text-sm font-mono text-muted-foreground flex items-center gap-1 bg-secondary/50 px-2 py-0.5 rounded">
              <Hash className="h-3 w-3" />
              INC-{incident.id.toString().padStart(4, '0')}
            </span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight">{incident.title}</h1>
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto bg-card p-2 border rounded-md shadow-sm shrink-0">
          <span className="text-xs font-mono font-bold tracking-widest text-muted-foreground pl-3">STATUS:</span>
          <Select value={status} onValueChange={handleStatusChange}>
            <SelectTrigger className="w-[160px] h-10 border-none bg-secondary/50 focus:ring-0 font-mono text-sm uppercase tracking-wider font-bold">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="open">OPEN</SelectItem>
              <SelectItem value="monitoring">MONITORING</SelectItem>
              <SelectItem value="escalated">ESCALATED</SelectItem>
              <SelectItem value="resolved">RESOLVED</SelectItem>
              <SelectItem value="closed">CLOSED</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        <Card className="lg:col-span-2 border-border shadow-sm">
          <CardHeader className="bg-muted/10 border-b border-border/50">
            <CardTitle className="text-sm font-mono tracking-widest text-muted-foreground uppercase flex items-center gap-2">
              <FileText className="h-4 w-4" /> Official Record Narrative
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 md:p-8">
            <div className="prose prose-sm md:prose-base dark:prose-invert max-w-none whitespace-pre-wrap font-sans leading-relaxed text-foreground/90">
              {incident.description || "No detailed narrative provided for this record."}
            </div>
          </CardContent>
        </Card>
        
        <div className="space-y-6">
          <Card className="border-border shadow-sm">
            <CardHeader className="bg-muted/10 border-b border-border/50 py-4">
              <CardTitle className="text-sm font-mono tracking-widest text-muted-foreground uppercase">
                Metadata & Context
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0 divide-y divide-border/50">
              <div className="p-4 space-y-1.5 hover:bg-muted/5 transition-colors">
                <div className="text-xs font-mono tracking-widest text-muted-foreground flex items-center gap-2">
                  <Calendar className="h-3 w-3" /> DATE OCCURRED
                </div>
                <div className="text-sm font-bold">{formatDate(incident.occurredAt)}</div>
              </div>
              
              <div className="p-4 space-y-1.5 hover:bg-muted/5 transition-colors">
                <div className="text-xs font-mono tracking-widest text-muted-foreground flex items-center gap-2">
                  <Clock className="h-3 w-3" /> LOGGED AT
                </div>
                <div className="text-sm">{formatDate(incident.createdAt)}</div>
              </div>

              {incident.location && (
                <div className="p-4 space-y-1.5 hover:bg-muted/5 transition-colors">
                  <div className="text-xs font-mono tracking-widest text-muted-foreground flex items-center gap-2">
                    <MapPin className="h-3 w-3" /> LOCATION
                  </div>
                  <div className="text-sm font-medium">{incident.location}</div>
                </div>
              )}

              {incident.involvedParties && (
                <div className="p-4 space-y-1.5 hover:bg-muted/5 transition-colors">
                  <div className="text-xs font-mono tracking-widest text-muted-foreground flex items-center gap-2">
                    <Users className="h-3 w-3" /> PARTIES INVOLVED
                  </div>
                  <div className="text-sm font-medium">{incident.involvedParties}</div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-destructive/30 bg-destructive/5 shadow-none">
            <CardContent className="p-4 space-y-4">
              <div className="text-sm text-destructive font-mono uppercase tracking-widest font-bold flex items-center gap-2">
                <AlertTriangle className="h-4 w-4" /> Danger Zone
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Deleting this record will permanently remove it from the system, breaking narrative continuity.
              </p>
              <Button 
                variant="destructive" 
                className="w-full font-bold tracking-widest text-xs h-10"
                onClick={handleDelete}
              >
                <Trash2 className="mr-2 h-4 w-4" />
                ERASE RECORD
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}