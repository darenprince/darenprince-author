import {
  useGetSosAlerts,
  useTriggerSos,
  useResolveSos,
  getGetSosAlertsQueryKey,
  getGetDashboardSummaryQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Radio, ShieldAlert, CheckCircle, Clock, MapPin, AlertTriangle } from "lucide-react";
import { formatDate } from "@/lib/format";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

export default function SosCenter() {
  const { data: alerts, isLoading } = useGetSosAlerts({
    query: { queryKey: getGetSosAlertsQueryKey() },
  });

  const queryClient = useQueryClient();
  const { toast } = useToast();
  const triggerSos = useTriggerSos();
  const resolveSos = useResolveSos();

  const [isTriggerOpen, setIsTriggerOpen] = useState(false);
  const [message, setMessage] = useState("");

  const activeAlert = alerts?.find((a) => a.status === "active");
  const pastAlerts = alerts?.filter((a) => a.status !== "active") || [];

  const handleTrigger = () => {
    triggerSos.mutate(
      { data: { message, includesLocation: true } },
      {
        onSuccess: () => {
          toast({
            title: "SOS TRIGGERED",
            description: "Distress signal has been broadcasted.",
            variant: "destructive",
          });
          queryClient.invalidateQueries({ queryKey: getGetSosAlertsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
          setIsTriggerOpen(false);
          setMessage("");
        },
        onError: (err) => {
          toast({
            title: "Failed to trigger SOS",
            description: err.message || "An error occurred",
            variant: "destructive",
          });
        },
      }
    );
  };

  const handleResolve = () => {
    if (!activeAlert) return;
    resolveSos.mutate(
      { id: activeAlert.id },
      {
        onSuccess: () => {
          toast({
            title: "SOS Resolved",
            description: "The distress signal has been cancelled.",
          });
          queryClient.invalidateQueries({ queryKey: getGetSosAlertsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
        },
      }
    );
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-[400px]" />
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-4xl mx-auto">
      <div className="border-b border-border/50 pb-6">
        <h1 className="text-3xl font-bold tracking-tight mb-2 flex items-center gap-3">
          <Radio className="h-8 w-8 text-destructive" />
          Distress Signal
        </h1>
        <p className="text-muted-foreground font-mono text-sm">
          Emergency broadcast and coordination center
        </p>
      </div>

      {activeAlert ? (
        <Card className="border-destructive bg-destructive/10 animate-pulse-subtle shadow-[0_0_50px_rgba(220,38,38,0.2)] relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-destructive/20 to-transparent pointer-events-none" />
          <div className="absolute top-0 left-0 w-1.5 h-full bg-destructive" />
          <CardHeader className="relative z-10 border-b border-destructive/20 pb-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-4 bg-destructive/20 rounded-full">
                  <ShieldAlert className="h-10 w-10 text-destructive animate-pulse" />
                </div>
                <div>
                  <CardTitle className="text-3xl font-black text-destructive tracking-widest">
                    ACTIVE SOS
                  </CardTitle>
                  <CardDescription className="text-destructive/80 font-mono mt-1 text-sm">
                    Broadcasting since {formatDate(activeAlert.triggeredAt)}
                  </CardDescription>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6 pt-6 relative z-10">
            <div className="bg-background/80 p-5 rounded-md border border-destructive/30 text-sm font-mono space-y-3 backdrop-blur-sm">
              <div className="flex justify-between items-center pb-2 border-b border-destructive/20">
                <span className="text-muted-foreground">EVENT ID:</span>
                <span className="font-bold text-destructive">
                  SOS-{activeAlert.id.toString().padStart(4, "0")}
                </span>
              </div>
              <div className="flex justify-between items-start gap-4">
                <span className="text-muted-foreground whitespace-nowrap">MESSAGE:</span>
                <span className="text-right">{activeAlert.message || "No message provided"}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">LOCATION:</span>
                <span className="flex items-center gap-1 text-primary">
                  {activeAlert.includesLocation ? (
                    <>
                      <MapPin className="h-4 w-4" /> Transmitting
                    </>
                  ) : (
                    "Not included"
                  )}
                </span>
              </div>
            </div>

            <Button
              size="lg"
              className="w-full border-2 border-destructive bg-destructive/20 text-destructive hover:bg-destructive hover:text-destructive-foreground font-bold tracking-widest h-14 text-lg transition-colors"
              onClick={handleResolve}
              disabled={resolveSos.isPending}
            >
              <CheckCircle className="mr-2 h-6 w-6" />
              {resolveSos.isPending ? "RESOLVING..." : "RESOLVE & STAND DOWN"}
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-border bg-card shadow-lg relative overflow-hidden">
          <div className="absolute inset-0 dot-pattern opacity-10 pointer-events-none" />
          <CardHeader className="text-center pb-4 pt-8 relative z-10">
            <CardTitle className="text-3xl font-bold tracking-tight">ARM SYSTEM</CardTitle>
            <CardDescription className="text-base max-w-lg mx-auto">
              Activating SOS will immediately notify your trusted contacts based on their
              notification preferences, including your live location.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center py-16 relative z-10">
            <Dialog open={isTriggerOpen} onOpenChange={setIsTriggerOpen}>
              <DialogTrigger asChild>
                <button className="relative group rounded-full outline-none focus:ring-4 focus:ring-destructive/50 transition-all">
                  <div className="absolute inset-0 bg-destructive rounded-full blur-2xl opacity-20 group-hover:opacity-60 group-active:opacity-80 transition-opacity duration-300" />
                  <div className="w-56 h-56 sm:w-72 sm:h-72 rounded-full bg-gradient-to-b from-red-600 to-red-950 border-8 border-background flex items-center justify-center shadow-2xl relative overflow-hidden group-active:scale-[0.98] transition-transform duration-150 ease-out">
                    <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(255,255,255,0.2)_0%,_transparent_60%)] opacity-50" />
                    <span className="text-white font-black text-5xl sm:text-6xl tracking-widest drop-shadow-[0_4px_10px_rgba(0,0,0,0.5)] font-sans relative z-10">
                      SOS
                    </span>
                  </div>
                </button>
              </DialogTrigger>
              <DialogContent className="border-destructive/50 border-2">
                <DialogHeader>
                  <DialogTitle className="text-destructive flex items-center gap-3 text-2xl uppercase tracking-wider font-bold">
                    <AlertTriangle className="h-8 w-8" />
                    Confirm SOS Broadcast
                  </DialogTitle>
                  <DialogDescription className="text-base">
                    This action cannot be silently undone. Contacts will be alerted immediately.
                  </DialogDescription>
                </DialogHeader>

                <div className="py-6 space-y-4">
                  <div className="space-y-3">
                    <Label
                      htmlFor="message"
                      className="font-mono text-xs uppercase tracking-widest"
                    >
                      Context / Instructions (Optional)
                    </Label>
                    <Textarea
                      id="message"
                      placeholder="e.g. Someone is outside. Contacting police."
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      className="bg-background min-h-[100px]"
                    />
                  </div>
                </div>

                <DialogFooter className="sm:justify-between gap-3">
                  <Button
                    variant="ghost"
                    onClick={() => setIsTriggerOpen(false)}
                    className="font-mono tracking-wider"
                  >
                    ABORT
                  </Button>
                  <Button
                    variant="destructive"
                    size="lg"
                    onClick={handleTrigger}
                    disabled={triggerSos.isPending}
                    className="font-bold tracking-widest flex-1 sm:flex-none h-12"
                  >
                    <Radio className="mr-2 h-5 w-5 animate-pulse" />
                    {triggerSos.isPending ? "BROADCASTING..." : "CONFIRM BROADCAST"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
            <p className="mt-12 text-sm text-muted-foreground font-mono uppercase tracking-widest text-center">
              Requires confirmation prompt
            </p>
          </CardContent>
        </Card>
      )}

      <div className="pt-8 border-t border-border/50">
        <h3 className="text-sm font-mono tracking-widest uppercase text-muted-foreground mb-6 flex items-center gap-2">
          <Clock className="h-4 w-4" />
          Broadcast History
        </h3>

        {pastAlerts.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground font-mono text-sm border border-dashed rounded-lg bg-card/30">
            No historical alerts recorded in the system.
          </div>
        ) : (
          <div className="space-y-4">
            {pastAlerts.map((alert) => (
              <Card
                key={alert.id}
                className="border-border bg-card/50 shadow-none hover:bg-card transition-colors"
              >
                <CardContent className="p-5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-3">
                      <Badge
                        variant="outline"
                        className="font-mono text-[10px] uppercase text-muted-foreground"
                      >
                        {alert.status}
                      </Badge>
                      <span className="text-sm font-mono font-medium">
                        {formatDate(alert.triggeredAt)}
                      </span>
                    </div>
                    {alert.message && (
                      <p className="text-sm border-l-2 border-muted pl-3 mt-2">{alert.message}</p>
                    )}
                  </div>
                  {alert.resolvedAt && (
                    <div className="text-left sm:text-right text-xs font-mono bg-secondary/50 p-2 rounded w-full sm:w-auto">
                      <div className="text-muted-foreground mb-1">RESOLVED AT</div>
                      <div className="font-medium">{formatDate(alert.resolvedAt)}</div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
