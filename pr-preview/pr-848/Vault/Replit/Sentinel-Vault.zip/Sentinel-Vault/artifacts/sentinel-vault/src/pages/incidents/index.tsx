import { useGetIncidents, getGetIncidentsQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, Plus, Search, MapPin, Calendar, ArrowRight, ShieldAlert } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { formatDate } from "@/lib/format";

export default function Incidents() {
  const { data: incidents, isLoading } = useGetIncidents({
    query: { queryKey: getGetIncidentsQueryKey() }
  });

  const [searchTerm, setSearchTerm] = useState("");
  const [severityFilter, setSeverityFilter] = useState("all");

  const filteredIncidents = incidents?.filter(inc => {
    const matchesSearch = inc.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          (inc.description && inc.description.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesSeverity = severityFilter === "all" || inc.severity === severityFilter;
    return matchesSearch && matchesSeverity;
  });

  const getSeverityColor = (sev: string) => {
    switch(sev) {
      case 'critical': return 'bg-destructive/20 text-destructive border-destructive/30';
      case 'high': return 'bg-primary/20 text-primary border-primary/30';
      case 'medium': return 'bg-amber-500/20 text-amber-500 border-amber-500/30';
      case 'low': return 'bg-blue-500/20 text-blue-500 border-blue-500/30';
      default: return 'bg-secondary text-foreground border-border';
    }
  };

  const getSeverityBadge = (sev: string) => {
    switch(sev) {
      case 'critical': return 'bg-destructive text-destructive-foreground hover:bg-destructive/90';
      case 'high': return 'bg-primary text-primary-foreground hover:bg-primary/90';
      case 'medium': return 'bg-amber-500 text-amber-950 hover:bg-amber-500/90';
      case 'low': return 'bg-blue-500 text-white hover:bg-blue-500/90';
      default: return 'bg-secondary text-secondary-foreground';
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-12 w-1/3" />
        <div className="space-y-4">
          {[1,2,3,4].map(i => <Skeleton key={i} className="h-32 w-full" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-5xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-border/50 pb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2 flex items-center gap-3">
            <AlertTriangle className="h-8 w-8 text-primary" />
            Incident Logs
          </h1>
          <p className="text-muted-foreground font-mono text-sm">Chronological threat and event documentation</p>
        </div>
        <Link href="/incidents/new">
          <Button className="gap-2 font-bold tracking-widest h-12 px-6">
            <Plus className="h-4 w-4" /> LOG INCIDENT
          </Button>
        </Link>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 bg-card p-4 border rounded-lg shadow-sm">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search records..." 
            className="pl-9 bg-background h-10 font-mono text-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Select value={severityFilter} onValueChange={setSeverityFilter}>
          <SelectTrigger className="w-full sm:w-[200px] bg-background h-10 font-mono text-sm uppercase">
            <SelectValue placeholder="Severity" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">ALL SEVERITIES</SelectItem>
            <SelectItem value="critical">CRITICAL</SelectItem>
            <SelectItem value="high">HIGH</SelectItem>
            <SelectItem value="medium">MEDIUM</SelectItem>
            <SelectItem value="low">LOW</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {!filteredIncidents || filteredIncidents.length === 0 ? (
        <div className="text-center py-20 border border-dashed rounded-lg bg-card/30">
          <ShieldAlert className="h-16 w-16 text-muted-foreground/30 mx-auto mb-6" />
          <h3 className="text-xl font-bold mb-2">No Records Found</h3>
          <p className="text-muted-foreground text-sm max-w-sm mx-auto">
            {searchTerm ? "No incidents match your search criteria." : "No incidents have been recorded yet. Use this space to document threats, events, and encounters."}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredIncidents.map(inc => (
            <Link key={inc.id} href={`/incidents/${inc.id}`}>
              <Card className="hover:border-primary/50 hover:bg-card transition-all duration-300 cursor-pointer border-border group overflow-hidden relative shadow-sm">
                <div className={`absolute top-0 left-0 w-1 h-full ${
                  inc.severity === 'critical' ? 'bg-destructive' : 
                  inc.severity === 'high' ? 'bg-primary' : 
                  inc.severity === 'medium' ? 'bg-amber-500' : 'bg-blue-500'
                }`} />
                <CardContent className="p-5 flex flex-col sm:flex-row gap-5 items-start sm:items-center ml-2">
                  <div className={`p-3 rounded-lg border shrink-0 hidden sm:flex ${getSeverityColor(inc.severity)}`}>
                    <AlertTriangle className="h-6 w-6" />
                  </div>
                  
                  <div className="flex-1 space-y-3 min-w-0 w-full">
                    <div className="flex flex-wrap items-center gap-3">
                      <Badge className={`${getSeverityBadge(inc.severity)} uppercase font-bold tracking-widest text-[10px] border-none`}>
                        {inc.severity}
                      </Badge>
                      <h3 className="text-xl font-bold group-hover:text-primary transition-colors truncate">{inc.title}</h3>
                    </div>
                    
                    <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed">
                      {inc.description || "No detailed description provided."}
                    </p>
                    
                    <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-xs font-mono text-muted-foreground pt-1">
                      <span className="flex items-center gap-1.5 bg-secondary/50 px-2 py-1 rounded">
                        <Calendar className="h-3 w-3" />
                        {formatDate(inc.occurredAt || inc.createdAt)}
                      </span>
                      {inc.location && (
                        <span className="flex items-center gap-1.5">
                          <MapPin className="h-3 w-3 text-primary/70" />
                          <span className="truncate max-w-[150px]">{inc.location}</span>
                        </span>
                      )}
                      <span className="uppercase tracking-widest font-bold">
                        STATUS: {inc.status}
                      </span>
                    </div>
                  </div>
                  
                  <div className="hidden sm:flex p-3 rounded-full bg-secondary/50 text-muted-foreground group-hover:text-primary group-hover:bg-primary/10 transition-colors shrink-0">
                    <ArrowRight className="h-5 w-5" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}