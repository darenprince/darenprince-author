import { useCreateIncident, getGetIncidentsQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { AlertTriangle, ArrowLeft, ShieldAlert } from "lucide-react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Link, useLocation } from "wouter";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function NewIncident() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const createIncident = useCreateIncident();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [severity, setSeverity] = useState("medium");
  const [location, setIncidentLocation] = useState("");
  const [involvedParties, setInvolvedParties] = useState("");
  const [occurredAt, setOccurredAt] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createIncident.mutate({
      data: {
        title,
        description,
        severity: severity as any,
        location,
        involvedParties,
        occurredAt: occurredAt ? new Date(occurredAt).toISOString() : undefined
      }
    }, {
      onSuccess: () => {
        toast({ title: "Incident Logged", description: "Record has been securely saved to the archive." });
        queryClient.invalidateQueries({ queryKey: getGetIncidentsQueryKey() });
        setLocation("/incidents");
      },
      onError: (err) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      }
    });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500 max-w-4xl mx-auto">
      <Link href="/incidents">
        <Button variant="ghost" size="sm" className="mb-2 -ml-3 text-muted-foreground font-mono tracking-widest hover:text-foreground">
          <ArrowLeft className="mr-2 h-4 w-4" />
          CANCEL DRAFT
        </Button>
      </Link>

      <div className="border-b border-border/50 pb-6">
        <h1 className="text-3xl font-bold tracking-tight mb-2 flex items-center gap-3">
          <AlertTriangle className="h-8 w-8 text-primary" />
          Log Incident Record
        </h1>
        <p className="text-muted-foreground font-mono text-sm max-w-2xl">Create a permanent, timestamped record of an event. Stick to objective facts: who, what, when, where, and how.</p>
      </div>

      <Card className="border-border shadow-md bg-card relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1.5 bg-primary" />
        <CardContent className="pt-8 md:p-8">
          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="space-y-6">
              <div className="space-y-3">
                <Label htmlFor="title" className="font-mono text-xs uppercase tracking-widest font-bold">Event Summary / Title *</Label>
                <Input 
                  id="title" 
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="e.g. Confrontation at parking lot, Unwanted contact via email"
                  required
                  className="bg-background h-12 text-base"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-secondary/30 p-5 rounded-lg border border-border/50">
                <div className="space-y-3">
                  <Label htmlFor="severity" className="font-mono text-xs uppercase tracking-widest font-bold">Severity Level</Label>
                  <Select value={severity} onValueChange={setSeverity}>
                    <SelectTrigger className="bg-background h-12">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low - Note to file / Observation</SelectItem>
                      <SelectItem value="medium">Medium - Concerning behavior</SelectItem>
                      <SelectItem value="high">High - Direct threat / Harassment</SelectItem>
                      <SelectItem value="critical">Critical - Physical danger / Harm</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-3">
                  <Label htmlFor="occurredAt" className="font-mono text-xs uppercase tracking-widest font-bold flex justify-between">
                    <span>Date & Time</span>
                    <span className="text-muted-foreground font-normal">Optional</span>
                  </Label>
                  <Input 
                    id="occurredAt" 
                    type="datetime-local"
                    value={occurredAt}
                    onChange={e => setOccurredAt(e.target.value)}
                    className="bg-background h-12"
                  />
                  <p className="text-[10px] text-muted-foreground font-mono">Leave blank to use current system time</p>
                </div>
              </div>

              <div className="space-y-3">
                <Label htmlFor="description" className="font-mono text-xs uppercase tracking-widest font-bold">Comprehensive Narrative</Label>
                <Textarea 
                  id="description" 
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  placeholder="Provide as much objective detail as possible. Stick to facts. Describe exactly what happened, what was said, and how it ended."
                  className="min-h-[250px] bg-background text-base leading-relaxed p-4"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <Label htmlFor="location" className="font-mono text-xs uppercase tracking-widest font-bold">Physical Location / Medium</Label>
                  <Input 
                    id="location" 
                    value={location}
                    onChange={e => setIncidentLocation(e.target.value)}
                    placeholder="e.g. 123 Main St, Phone Call, Twitter"
                    className="bg-background h-12"
                  />
                </div>
                <div className="space-y-3">
                  <Label htmlFor="involvedParties" className="font-mono text-xs uppercase tracking-widest font-bold">Involved Parties / Actors</Label>
                  <Input 
                    id="involvedParties" 
                    value={involvedParties}
                    onChange={e => setInvolvedParties(e.target.value)}
                    placeholder="Names, descriptions, vehicle info"
                    className="bg-background h-12"
                  />
                </div>
              </div>
            </div>

            <div className="flex flex-col-reverse sm:flex-row justify-end gap-4 pt-6 border-t border-border/50">
              <Link href="/incidents">
                <Button type="button" variant="ghost" className="w-full sm:w-auto h-14 font-mono tracking-widest">ABORT</Button>
              </Link>
              <Button 
                type="submit" 
                disabled={!title || createIncident.isPending} 
                className="w-full sm:w-auto font-bold tracking-widest h-14 px-8 text-lg"
              >
                {createIncident.isPending ? "ENCRYPTING & SAVING..." : "COMMIT TO ARCHIVE"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}