import { useGetAuditLog, getGetAuditLogQueryKey } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollText, Shield, Database, AlertTriangle, Timer, Users2, Radio, Skull, Settings2, LogIn, Upload, Lock } from "lucide-react";
import { useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { formatDate, formatTimeAgo } from "@/lib/format";

const CATEGORY_CONFIG: Record<string, { icon: any; color: string; label: string }> = {
  evidence: { icon: Database, color: "text-blue-400 bg-blue-500/15 border-blue-500/20", label: "Evidence" },
  security: { icon: AlertTriangle, color: "text-amber-400 bg-amber-500/15 border-amber-500/20", label: "Security" },
  safety: { icon: Timer, color: "text-green-400 bg-green-500/15 border-green-500/20", label: "Safety" },
  contacts: { icon: Users2, color: "text-purple-400 bg-purple-500/15 border-purple-500/20", label: "Contacts" },
  deadman: { icon: Skull, color: "text-primary bg-primary/15 border-primary/20", label: "Deadman" },
  emergency: { icon: Radio, color: "text-destructive bg-destructive/15 border-destructive/20", label: "Emergency" },
  auth: { icon: LogIn, color: "text-cyan-400 bg-cyan-500/15 border-cyan-500/20", label: "Auth" },
  system: { icon: Settings2, color: "text-muted-foreground bg-secondary border-border", label: "System" },
};

export default function AuditLogPage() {
  const [category, setCategory] = useState("all");
  const [limit] = useState(50);

  const params = {
    category: category !== "all" ? category : undefined,
    limit,
  };

  const { data, isLoading } = useGetAuditLog(params, {
    query: {
      queryKey: getGetAuditLogQueryKey(params),
    },
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-12 w-1/3" />
        <div className="space-y-3">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Skeleton key={i} className="h-16 w-full" />
          ))}
        </div>
      </div>
    );
  }

  const logs = data?.logs || [];
  const total = data?.total || 0;

  return (
    <div className="space-y-6 animate-in fade-in duration-500 max-w-5xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-border/50 pb-6">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight mb-1.5 flex items-center gap-2.5">
            <ScrollText className="h-6 w-6 text-primary" />
            Audit Log
          </h1>
          <p className="text-muted-foreground text-sm">
            {total} total events recorded
          </p>
        </div>
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="w-full sm:w-[200px] bg-card h-9 text-sm">
            <SelectValue placeholder="Filter by category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            <SelectItem value="evidence">Evidence</SelectItem>
            <SelectItem value="security">Security</SelectItem>
            <SelectItem value="safety">Safety</SelectItem>
            <SelectItem value="contacts">Contacts</SelectItem>
            <SelectItem value="deadman">Deadman</SelectItem>
            <SelectItem value="emergency">Emergency</SelectItem>
            <SelectItem value="auth">Authentication</SelectItem>
            <SelectItem value="system">System</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {logs.length === 0 ? (
        <div className="text-center py-20 border border-dashed rounded-lg bg-card/30">
          <ScrollText className="h-14 w-14 text-muted-foreground/30 mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-1">No Events Found</h3>
          <p className="text-muted-foreground text-sm max-w-sm mx-auto">
            {category !== "all" ? "No events match the selected category filter." : "No audit events have been recorded yet."}
          </p>
        </div>
      ) : (
        <div className="relative">
          <div className="absolute left-[23px] top-2 bottom-2 w-px bg-border/50 hidden sm:block" />

          <div className="space-y-1">
            {logs.map((log) => {
              const config = CATEGORY_CONFIG[log.category] || CATEGORY_CONFIG.system;
              const CatIcon = config.icon;

              return (
                <div
                  key={log.id}
                  className="group flex items-start gap-3 px-2 py-2.5 rounded-lg hover:bg-card/60 transition-colors relative"
                >
                  <div className={`w-[34px] h-[34px] rounded-md border flex items-center justify-center flex-shrink-0 relative z-10 ${config.color}`}>
                    <CatIcon className="h-4 w-4" />
                  </div>

                  <div className="flex-1 min-w-0 flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium leading-tight truncate">{log.description}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[11px] text-muted-foreground font-mono">{log.action}</span>
                        {log.ipAddress && (
                          <span className="text-[11px] text-muted-foreground/50 font-mono hidden sm:inline">{log.ipAddress}</span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 flex-shrink-0">
                      <Badge variant="outline" className="text-[10px] font-mono uppercase tracking-wider border-border/50 px-1.5 py-0 h-5">
                        {config.label}
                      </Badge>
                      <span className="text-[11px] text-muted-foreground font-mono whitespace-nowrap" title={formatDate(log.createdAt)}>
                        {formatTimeAgo(log.createdAt)}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
