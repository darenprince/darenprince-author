import { useGetCheckins, useCreateCheckin, useConfirmCheckin, useDeleteCheckin, getGetCheckinsQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Clock, Plus, ShieldCheck, Trash2, CheckCircle2, Timer } from "lucide-react";
import { formatDate } from "@/lib/format";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";

export default function Checkins() {
  const { data: checkins, isLoading } = useGetCheckins({
    query: { queryKey: getGetCheckinsQueryKey() }
  });

  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const createCheckin = useCreateCheckin();
  const confirmCheckin = useConfirmCheckin();
  const deleteCheckin = useDeleteCheckin();

  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [newLabel, setNewLabel] = useState("");
  const [newInterval, setNewInterval] = useState("60");
  const [newNotes, setNewNotes] = useState("");
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleCreate = () => {
    createCheckin.mutate({
      data: {
        label: newLabel,
        intervalMinutes: parseInt(newInterval, 10),
        notes: newNotes || undefined
      }
    }, {
      onSuccess: () => {
        toast({ title: "Timer Armed", description: "Check-in timer started." });
        queryClient.invalidateQueries({ queryKey: getGetCheckinsQueryKey() });
        setIsCreateOpen(false);
        setNewLabel("");
        setNewInterval("60");
        setNewNotes("");
      },
      onError: (err) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      }
    });
  };

  const handleConfirm = (id: number) => {
    confirmCheckin.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Check-in Confirmed", description: "Timer reset successfully." });
        queryClient.invalidateQueries({ queryKey: getGetCheckinsQueryKey() });
      }
    });
  };

  const handleDelete = (id: number) => {
    deleteCheckin.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Timer Disarmed", description: "Check-in timer cancelled." });
        queryClient.invalidateQueries({ queryKey: getGetCheckinsQueryKey() });
      }
    });
  };

  const getRemainingTime = (dueAt: string) => {
    const diff = new Date(dueAt).getTime() - now.getTime();
    if (diff <= 0) return { text: "OVERDUE", isOverdue: true };
    
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const secs = Math.floor((diff % (1000 * 60)) / 1000);
    
    return {
      text: `${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`,
      isOverdue: false
    };
  };

  if (isLoading) {
    return <div className="space-y-4"><Skeleton className="h-[200px]" /><Skeleton className="h-[200px]" /></div>;
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-5xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-border/50 pb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2 flex items-center gap-3">
            <Timer className="h-8 w-8 text-primary" />
            Check-in Timers
          </h1>
          <p className="text-muted-foreground font-mono text-sm">Dead-man switches and safety intervals</p>
        </div>

        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 font-bold tracking-widest">
              <Plus className="h-4 w-4" /> ARM NEW TIMER
            </Button>
          </DialogTrigger>
          <DialogContent className="border-border bg-card">
            <DialogHeader>
              <DialogTitle className="text-primary font-mono uppercase tracking-widest flex items-center gap-2">
                <Timer className="h-5 w-5" /> Arm Check-in Timer
              </DialogTitle>
              <DialogDescription>
                Set a timer. If you don't confirm your safety before it expires, your trusted contacts will be notified.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="label" className="font-mono text-xs uppercase tracking-widest">Timer Label / Context</Label>
                <Input 
                  id="label" 
                  placeholder="e.g. Meeting with source, Walk home"
                  value={newLabel}
                  onChange={(e) => setNewLabel(e.target.value)}
                  className="bg-background"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="interval" className="font-mono text-xs uppercase tracking-widest">Interval (Minutes)</Label>
                <Input 
                  id="interval" 
                  type="number"
                  min="5"
                  value={newInterval}
                  onChange={(e) => setNewInterval(e.target.value)}
                  className="bg-background"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="notes" className="font-mono text-xs uppercase tracking-widest">Notes for Contacts (Optional)</Label>
                <Textarea 
                  id="notes" 
                  placeholder="Where are you? Who are you with?"
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  className="bg-background"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setIsCreateOpen(false)} className="font-mono tracking-widest">CANCEL</Button>
              <Button onClick={handleCreate} disabled={!newLabel || !newInterval || createCheckin.isPending} className="font-bold tracking-widest">
                {createCheckin.isPending ? "ARMING..." : "ARM TIMER"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {!checkins || checkins.length === 0 ? (
        <Card className="bg-card/30 border-dashed border-2">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <ShieldCheck className="h-16 w-16 text-muted-foreground mb-6 opacity-30" />
            <h3 className="text-lg font-bold mb-2">No Active Timers</h3>
            <p className="text-muted-foreground text-sm max-w-sm">
              Arm a check-in timer when heading into a risky situation. 
              If you fail to check in, an alert is automatically raised.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {checkins.map((checkin) => {
            const isMissed = checkin.status === "missed";
            const isArmed = checkin.status === "armed";
            const { text: timeText, isOverdue } = isArmed || isMissed ? getRemainingTime(checkin.nextDueAt) : { text: "--:--:--", isOverdue: false };
            
            return (
              <Card key={checkin.id} className={`
                border overflow-hidden relative shadow-md transition-all
                ${isMissed ? 'border-destructive bg-destructive/5' : 'border-border bg-card'}
                ${isArmed ? 'hover:border-accent/50' : ''}
              `}>
                {isMissed && <div className="absolute top-0 left-0 w-1.5 h-full bg-destructive" />}
                {isArmed && <div className="absolute top-0 left-0 w-1.5 h-full bg-accent" />}
                
                <CardHeader className="pb-3 border-b border-border/50">
                  <div className="flex justify-between items-start">
                    <div className="space-y-1">
                      <CardTitle className="text-xl font-bold">{checkin.label}</CardTitle>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant={isMissed ? "destructive" : isArmed ? "default" : "secondary"} className={`font-mono text-[10px] tracking-wider uppercase ${isArmed ? 'bg-accent text-accent-foreground hover:bg-accent/80' : ''}`}>
                          {checkin.status}
                        </Badge>
                        <span className="text-xs font-mono text-muted-foreground">
                          {checkin.intervalMinutes}m interval
                        </span>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="py-6">
                  <div className="flex flex-col items-center justify-center space-y-2 mb-6">
                    <div className="text-xs font-mono tracking-widest text-muted-foreground">
                      {isMissed || isOverdue ? 'TIME EXPIRED' : 'TIME REMAINING'}
                    </div>
                    <div className={`text-5xl md:text-6xl font-black font-mono tracking-tight ${isMissed || isOverdue ? 'text-destructive animate-pulse' : 'text-accent'}`}>
                      {timeText}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-xs font-mono bg-background p-3 rounded-md border border-border/50">
                    <div>
                      <div className="text-muted-foreground mb-1">DUE AT</div>
                      <div className="font-bold text-foreground">
                        {formatDate(checkin.nextDueAt)}
                      </div>
                    </div>
                    <div>
                      <div className="text-muted-foreground mb-1">LAST CHECK-IN</div>
                      <div className="font-bold">{formatDate(checkin.lastConfirmedAt) || "Never"}</div>
                    </div>
                  </div>
                  
                  {checkin.notes && (
                    <div className="mt-4 text-sm text-muted-foreground border-l-2 border-primary/30 pl-3 italic bg-primary/5 p-2 rounded-r">
                      {checkin.notes}
                    </div>
                  )}
                </CardContent>
                <CardFooter className="pt-0 flex gap-3">
                  <Button 
                    className={`flex-1 font-bold tracking-widest h-12 text-sm ${isMissed ? 'bg-destructive hover:bg-destructive/90 text-destructive-foreground' : 'bg-primary hover:bg-primary/90 text-primary-foreground'}`}
                    onClick={() => handleConfirm(checkin.id)}
                    disabled={checkin.status === 'disarmed' || confirmCheckin.isPending}
                  >
                    <CheckCircle2 className="mr-2 h-5 w-5" />
                    I'M SAFE (RESET)
                  </Button>
                  <Button 
                    variant="outline" 
                    className="h-12 w-12 shrink-0 border-border hover:bg-destructive/10 hover:text-destructive hover:border-destructive/30"
                    onClick={() => handleDelete(checkin.id)}
                    disabled={deleteCheckin.isPending}
                    title="Disarm/Delete Timer"
                  >
                    <Trash2 className="h-5 w-5" />
                  </Button>
                </CardFooter>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}