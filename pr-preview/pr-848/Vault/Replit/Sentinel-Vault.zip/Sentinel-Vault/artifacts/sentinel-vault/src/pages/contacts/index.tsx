import { 
  useGetContacts, 
  useCreateContact, 
  useUpdateContact, 
  useDeleteContact,
  getGetContactsQueryKey 
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Users, Plus, User, Phone, Mail, ShieldAlert, Trash2, Bell, Radio, Timer, Skull } from "lucide-react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";

export default function Contacts() {
  const { data: contacts, isLoading } = useGetContacts({
    query: { queryKey: getGetContactsQueryKey() }
  });

  const queryClient = useQueryClient();
  const { toast } = useToast();
  const createContact = useCreateContact();
  const deleteContact = useDeleteContact();

  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [role, setRole] = useState("family");
  const [receivesSos, setReceivesSos] = useState(true);
  const [receivesCheckin, setReceivesCheckin] = useState(true);
  const [receivesDeadman, setReceivesDeadman] = useState(false);

  const handleCreate = () => {
    createContact.mutate({
      data: {
        name,
        email,
        phone,
        role: role as any,
        receivesSos,
        receivesCheckinFailure: receivesCheckin,
        receivesDeadmanRelease: receivesDeadman
      }
    }, {
      onSuccess: () => {
        toast({ title: "Contact Added", description: "Trusted circle updated." });
        queryClient.invalidateQueries({ queryKey: getGetContactsQueryKey() });
        setIsCreateOpen(false);
        // Reset form
        setName(""); setEmail(""); setPhone(""); setRole("family");
        setReceivesSos(true); setReceivesCheckin(true); setReceivesDeadman(false);
      },
      onError: (err) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      }
    });
  };

  const handleDelete = (id: number) => {
    if (!confirm("Remove this person from your trusted circle?")) return;
    deleteContact.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Contact Removed" });
        queryClient.invalidateQueries({ queryKey: getGetContactsQueryKey() });
      }
    });
  };

  const getRoleColor = (role: string) => {
    switch(role) {
      case 'attorney': return 'bg-primary/20 text-primary border-primary/30';
      case 'journalist': return 'bg-purple-500/20 text-purple-500 border-purple-500/30';
      case 'advocate': return 'bg-blue-500/20 text-blue-500 border-blue-500/30';
      case 'emergency_services': return 'bg-destructive/20 text-destructive border-destructive/30';
      default: return 'bg-secondary text-foreground border-border';
    }
  };

  if (isLoading) {
    return <div className="space-y-6"><Skeleton className="h-12 w-1/3" /><div className="grid grid-cols-1 md:grid-cols-2 gap-4"><Skeleton className="h-48" /><Skeleton className="h-48" /></div></div>;
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-5xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-border/50 pb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2 flex items-center gap-3">
            <Users className="h-8 w-8 text-primary" />
            Trusted Circle
          </h1>
          <p className="text-muted-foreground font-mono text-sm">Role-based emergency contacts and advocates</p>
        </div>

        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 font-bold tracking-widest h-12 px-6">
              <Plus className="h-4 w-4" /> ADD CONTACT
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md border-border">
            <DialogHeader>
              <DialogTitle className="text-primary font-mono tracking-widest uppercase flex items-center gap-2">
                <Users className="h-5 w-5" /> Add Trusted Contact
              </DialogTitle>
              <DialogDescription>
                Add an individual who will receive automated alerts and evidence based on your rules.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-5 py-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="font-mono text-xs uppercase tracking-widest">Name / Alias *</Label>
                <Input id="name" value={name} onChange={e => setName(e.target.value)} className="bg-background" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone" className="font-mono text-xs uppercase tracking-widest">Phone</Label>
                  <Input id="phone" value={phone} onChange={e => setPhone(e.target.value)} className="bg-background" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email" className="font-mono text-xs uppercase tracking-widest">Email</Label>
                  <Input id="email" type="email" value={email} onChange={e => setEmail(e.target.value)} className="bg-background" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="role" className="font-mono text-xs uppercase tracking-widest">Role</Label>
                <Select value={role} onValueChange={setRole}>
                  <SelectTrigger className="bg-background"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="family">Family / Friend</SelectItem>
                    <SelectItem value="attorney">Legal Counsel</SelectItem>
                    <SelectItem value="journalist">Journalist / Press</SelectItem>
                    <SelectItem value="advocate">Advocate / NGO</SelectItem>
                    <SelectItem value="emergency_services">Emergency Services</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="border-t border-border/50 pt-5 space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-widest text-primary font-mono flex items-center gap-2">
                  <Bell className="h-4 w-4" /> Routing Permissions
                </h4>
                
                <div className="flex items-center justify-between bg-background p-3 rounded-md border border-border/50">
                  <Label htmlFor="sos" className="flex flex-col gap-1.5 cursor-pointer">
                    <span className="font-bold flex items-center gap-2"><Radio className="h-4 w-4 text-destructive" /> SOS Alerts</span>
                    <span className="font-normal text-xs text-muted-foreground font-mono">Notified immediately when SOS triggered</span>
                  </Label>
                  <Switch id="sos" checked={receivesSos} onCheckedChange={setReceivesSos} />
                </div>
                
                <div className="flex items-center justify-between bg-background p-3 rounded-md border border-border/50">
                  <Label htmlFor="checkin" className="flex flex-col gap-1.5 cursor-pointer">
                    <span className="font-bold flex items-center gap-2"><Timer className="h-4 w-4 text-accent" /> Check-in Failures</span>
                    <span className="font-normal text-xs text-muted-foreground font-mono">Notified if you miss a safety timer</span>
                  </Label>
                  <Switch id="checkin" checked={receivesCheckin} onCheckedChange={setReceivesCheckin} />
                </div>
                
                <div className="flex items-center justify-between bg-background p-3 rounded-md border border-border/50">
                  <Label htmlFor="deadman" className="flex flex-col gap-1.5 cursor-pointer">
                    <span className="font-bold flex items-center gap-2"><Skull className="h-4 w-4 text-primary" /> Deadman Releases</span>
                    <span className="font-normal text-xs text-muted-foreground font-mono">Receives vault access if rule triggers</span>
                  </Label>
                  <Switch id="deadman" checked={receivesDeadman} onCheckedChange={setReceivesDeadman} />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setIsCreateOpen(false)} className="font-mono tracking-widest">CANCEL</Button>
              <Button onClick={handleCreate} disabled={!name || createContact.isPending} className="font-bold tracking-widest">
                SAVE CONTACT
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {!contacts || contacts.length === 0 ? (
        <Card className="bg-card/30 border-dashed border-2">
          <CardContent className="flex flex-col items-center justify-center py-20 text-center">
            <Users className="h-16 w-16 text-muted-foreground/30 mb-6" />
            <h3 className="text-xl font-bold mb-2">No Contacts Configured</h3>
            <p className="text-muted-foreground text-sm max-w-md mx-auto">
              Add trusted individuals, attorneys, or advocates who should be notified when an emergency protocol is triggered.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {contacts.map((contact) => (
            <Card key={contact.id} className="border-border hover:border-primary/30 transition-colors shadow-sm bg-card group">
              <CardHeader className="pb-4 border-b border-border/50">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-4">
                    <div className={`h-12 w-12 rounded-lg border flex items-center justify-center ${getRoleColor(contact.role)}`}>
                      <User className="h-6 w-6" />
                    </div>
                    <div>
                      <CardTitle className="text-xl">{contact.name}</CardTitle>
                      <Badge variant="outline" className="mt-2 font-mono text-[10px] uppercase tracking-widest border-border">
                        ROLE: {contact.role.replace('_', ' ')}
                      </Badge>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive hover:bg-destructive/10 opacity-0 group-hover:opacity-100 transition-opacity" onClick={() => handleDelete(contact.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="pt-4 space-y-5">
                <div className="space-y-3 text-sm">
                  {contact.phone ? (
                    <div className="flex items-center gap-3">
                      <Phone className="h-4 w-4 text-muted-foreground" /> <span className="font-mono">{contact.phone}</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-3 opacity-30">
                      <Phone className="h-4 w-4" /> <span className="font-mono text-xs">No phone provided</span>
                    </div>
                  )}
                  {contact.email ? (
                    <div className="flex items-center gap-3">
                      <Mail className="h-4 w-4 text-muted-foreground" /> <span className="font-mono">{contact.email}</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-3 opacity-30">
                      <Mail className="h-4 w-4" /> <span className="font-mono text-xs">No email provided</span>
                    </div>
                  )}
                </div>
                
                <div className="bg-background/50 rounded-md p-3 border border-border/50">
                  <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mb-3 font-bold">Active Routing</div>
                  <div className="flex flex-col gap-2">
                    {contact.receivesSos && (
                      <div className="flex items-center gap-2 text-xs font-mono font-bold text-destructive">
                        <Radio className="h-3 w-3" /> SOS ALERTS
                      </div>
                    )}
                    {contact.receivesCheckinFailure && (
                      <div className="flex items-center gap-2 text-xs font-mono font-bold text-accent">
                        <Timer className="h-3 w-3" /> CHECK-IN FAILURES
                      </div>
                    )}
                    {contact.receivesDeadmanRelease && (
                      <div className="flex items-center gap-2 text-xs font-mono font-bold text-primary">
                        <Skull className="h-3 w-3" /> DEADMAN RELEASES
                      </div>
                    )}
                    
                    {!contact.receivesSos && !contact.receivesCheckinFailure && !contact.receivesDeadmanRelease && (
                      <div className="text-xs font-mono text-muted-foreground italic">No active routing configured</div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}