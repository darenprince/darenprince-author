import { pgTable, text, serial, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const trustedContactsTable = pgTable("trusted_contacts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  relationship: text("relationship"),
  role: text("role").notNull().default("other"),
  receivesSos: boolean("receives_sos").notNull().default(false),
  receivesCheckinFailure: boolean("receives_checkin_failure").notNull().default(false),
  receivesDeadmanRelease: boolean("receives_deadman_release").notNull().default(false),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertTrustedContactSchema = createInsertSchema(trustedContactsTable).omit({ id: true, createdAt: true });
export type InsertTrustedContact = z.infer<typeof insertTrustedContactSchema>;
export type TrustedContact = typeof trustedContactsTable.$inferSelect;
