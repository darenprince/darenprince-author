import { pgTable, text, serial, timestamp, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const sosAlertsTable = pgTable("sos_alerts", {
  id: serial("id").primaryKey(),
  status: text("status").notNull().default("active"),
  message: text("message"),
  location: text("location"),
  includesLocation: boolean("includes_location").notNull().default(false),
  notifiedContactIds: integer("notified_contact_ids").array(),
  triggeredAt: timestamp("triggered_at", { withTimezone: true }).notNull().defaultNow(),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
});

export const insertSosAlertSchema = createInsertSchema(sosAlertsTable).omit({ id: true, triggeredAt: true });
export type InsertSosAlert = z.infer<typeof insertSosAlertSchema>;
export type SosAlert = typeof sosAlertsTable.$inferSelect;
