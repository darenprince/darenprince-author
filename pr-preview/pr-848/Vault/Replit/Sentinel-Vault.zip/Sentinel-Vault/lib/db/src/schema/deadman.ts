import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const deadmanRulesTable = pgTable("deadman_rules", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  triggerAfterHours: integer("trigger_after_hours").notNull(),
  status: text("status").notNull().default("active"),
  releaseTarget: text("release_target").notNull().default("trusted_circle"),
  gracePeriodMinutes: integer("grace_period_minutes").notNull().default(60),
  vaultIds: integer("vault_ids").array(),
  contactIds: integer("contact_ids").array(),
  lastRenewedAt: timestamp("last_renewed_at", { withTimezone: true }).notNull().defaultNow(),
  willTriggerAt: timestamp("will_trigger_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertDeadmanRuleSchema = createInsertSchema(deadmanRulesTable).omit({ id: true, createdAt: true });
export type InsertDeadmanRule = z.infer<typeof insertDeadmanRuleSchema>;
export type DeadmanRule = typeof deadmanRulesTable.$inferSelect;
