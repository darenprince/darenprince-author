import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const checkinsTable = pgTable("checkins", {
  id: serial("id").primaryKey(),
  label: text("label").notNull(),
  intervalMinutes: integer("interval_minutes").notNull(),
  status: text("status").notNull().default("armed"),
  lastConfirmedAt: timestamp("last_confirmed_at", { withTimezone: true }),
  nextDueAt: timestamp("next_due_at", { withTimezone: true }).notNull(),
  missedCount: integer("missed_count").notNull().default(0),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertCheckinSchema = createInsertSchema(checkinsTable).omit({ id: true, createdAt: true });
export type InsertCheckin = z.infer<typeof insertCheckinSchema>;
export type Checkin = typeof checkinsTable.$inferSelect;
